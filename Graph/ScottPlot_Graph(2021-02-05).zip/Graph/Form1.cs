﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ScottPlot;

namespace Graph
{
    public partial class Form1 : Form
    {
        Plot plt = new ScottPlot.Plot(600, 400);
        double[] x = new double[100];
        double[] y = new double[100];
        List<double> x_list;
        List<double> y_list;
        int x_idx = 0;
        int y_idx = 0;
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            x_list = new List<double> { 0 };
            y_list = new List<double> { 0 };

            formsPlot1.plt.Legend(); // 오른쪽 아래 그림박스 그리기
            formsPlot1.plt.Title("Scatter Plot Quickstart");
            formsPlot1.plt.XLabel("Horizontal Units");
            formsPlot1.plt.YLabel("Vertical Units");
            formsPlot1.plt.Style(ScottPlot.Style.Black);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            formsPlot1.plt.Clear();

            x_list.Add(++x_idx);
            y_list.Add(rand.NextDouble());

            formsPlot1.plt.PlotScatter(x_list.ToArray(), y_list.ToArray(), Color.White, 3, 0, "test", null, null , 1, 3, MarkerShape.filledCircle, LineStyle.Solid); // 실제 그래프에 들어가는 값
            formsPlot1.plt.AxisAuto(); // 자동으로 화면 업데이트(화면밖으로 나갈 경우 조정)
            formsPlot1.Render(); // 그래프 그리기
        }
    }
}
