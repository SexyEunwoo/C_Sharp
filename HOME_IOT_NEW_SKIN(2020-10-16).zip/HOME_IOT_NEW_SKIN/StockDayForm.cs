﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace HOME_IOT_NEW_SKIN
{
    public partial class StockDayForm : Form
    {
        public static Stock stockTodayPrice;

        public StockDayForm()
        {
            InitializeComponent();
        }

        private void StockDayForm_Load(object sender, EventArgs e)
        {
            stockTodayPrice = new Stock();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                XmlDocument stockDoc = new XmlDocument();
                stockDoc.Load(@"https://fchart.stock.naver.com/sise.nhn?symbol=092730&timeframe=day&count=1500&requestType=0");

                XmlNodeList chartDataList = stockDoc.SelectNodes("protocol/chartdata");
                XmlNode chartData = chartDataList[0];
                XmlNode todayNode = chartData.LastChild;
                string xmlStr = todayNode.OuterXml;
                stockTodayPrice.SetPrice("네오팜",xmlStr, "28050", 83);
            }
            catch (Exception error)
            {
                using (StreamWriter sw = new StreamWriter(new FileStream("Error.txt", FileMode.Append, FileAccess.Write)))
                {
                    string text = string.Format("{0} : {1}", DateTime.Now.ToString(), error.Message);

                    sw.WriteLine(text);
                }
            }
        }

        private void butAddEvent_Click(object sender, EventArgs e)
        {

        }

    }
}
