﻿namespace HOME_IOT_NEW_SKIN
{
    partial class StockDayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelStockDayFirstEvent = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelBeforePrice = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labBeforePriceName = new System.Windows.Forms.Label();
            this.panelCurPrice = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labCurPrice = new System.Windows.Forms.Label();
            this.labCurPriceName = new System.Windows.Forms.Label();
            this.panelStockDayFirstName = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panelStockDaySecondEvent = new System.Windows.Forms.Panel();
            this.panelStockDayThirdEvent = new System.Windows.Forms.Panel();
            this.panelStockDayFourthEvent = new System.Windows.Forms.Panel();
            this.butAddEvent = new System.Windows.Forms.Button();
            this.butDelEvent = new System.Windows.Forms.Button();
            this.panelStockDayFirstEvent.SuspendLayout();
            this.panelBeforePrice.SuspendLayout();
            this.panelCurPrice.SuspendLayout();
            this.panelStockDayFirstName.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelStockDayFirstEvent
            // 
            this.panelStockDayFirstEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panelStockDayFirstEvent.Controls.Add(this.panel2);
            this.panelStockDayFirstEvent.Controls.Add(this.panelBeforePrice);
            this.panelStockDayFirstEvent.Controls.Add(this.panelCurPrice);
            this.panelStockDayFirstEvent.Controls.Add(this.panelStockDayFirstName);
            this.panelStockDayFirstEvent.Location = new System.Drawing.Point(0, 38);
            this.panelStockDayFirstEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDayFirstEvent.Name = "panelStockDayFirstEvent";
            this.panelStockDayFirstEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDayFirstEvent.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(1, 299);
            this.panel2.Margin = new System.Windows.Forms.Padding(0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(385, 105);
            this.panel2.TabIndex = 3;
            // 
            // panelBeforePrice
            // 
            this.panelBeforePrice.Controls.Add(this.label4);
            this.panelBeforePrice.Controls.Add(this.label5);
            this.panelBeforePrice.Controls.Add(this.label6);
            this.panelBeforePrice.Controls.Add(this.labBeforePriceName);
            this.panelBeforePrice.Location = new System.Drawing.Point(1, 194);
            this.panelBeforePrice.Margin = new System.Windows.Forms.Padding(0);
            this.panelBeforePrice.Name = "panelBeforePrice";
            this.panelBeforePrice.Size = new System.Drawing.Size(385, 105);
            this.panelBeforePrice.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label4.Location = new System.Drawing.Point(280, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(105, 52);
            this.label4.TabIndex = 10;
            this.label4.Text = "+0.3%";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label5.Location = new System.Drawing.Point(280, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 52);
            this.label5.TabIndex = 9;
            this.label5.Text = "▼500";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Dock = System.Windows.Forms.DockStyle.Left;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(129, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(151, 105);
            this.label6.TabIndex = 8;
            this.label6.Text = "28,300";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBeforePriceName
            // 
            this.labBeforePriceName.BackColor = System.Drawing.Color.Transparent;
            this.labBeforePriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labBeforePriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labBeforePriceName.ForeColor = System.Drawing.Color.White;
            this.labBeforePriceName.Location = new System.Drawing.Point(0, 0);
            this.labBeforePriceName.Name = "labBeforePriceName";
            this.labBeforePriceName.Size = new System.Drawing.Size(129, 105);
            this.labBeforePriceName.TabIndex = 5;
            this.labBeforePriceName.Text = "전일가";
            this.labBeforePriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelCurPrice
            // 
            this.panelCurPrice.Controls.Add(this.label3);
            this.panelCurPrice.Controls.Add(this.label2);
            this.panelCurPrice.Controls.Add(this.labCurPrice);
            this.panelCurPrice.Controls.Add(this.labCurPriceName);
            this.panelCurPrice.Location = new System.Drawing.Point(1, 89);
            this.panelCurPrice.Margin = new System.Windows.Forms.Padding(0);
            this.panelCurPrice.Name = "panelCurPrice";
            this.panelCurPrice.Size = new System.Drawing.Size(385, 105);
            this.panelCurPrice.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(280, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 52);
            this.label3.TabIndex = 7;
            this.label3.Text = "+0.3%";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(280, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 52);
            this.label2.TabIndex = 6;
            this.label2.Text = "▲300";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labCurPrice
            // 
            this.labCurPrice.BackColor = System.Drawing.Color.Transparent;
            this.labCurPrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labCurPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labCurPrice.ForeColor = System.Drawing.Color.White;
            this.labCurPrice.Location = new System.Drawing.Point(129, 0);
            this.labCurPrice.Name = "labCurPrice";
            this.labCurPrice.Size = new System.Drawing.Size(151, 105);
            this.labCurPrice.TabIndex = 5;
            this.labCurPrice.Text = "28,600";
            this.labCurPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labCurPriceName
            // 
            this.labCurPriceName.BackColor = System.Drawing.Color.Transparent;
            this.labCurPriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labCurPriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labCurPriceName.ForeColor = System.Drawing.Color.White;
            this.labCurPriceName.Location = new System.Drawing.Point(0, 0);
            this.labCurPriceName.Name = "labCurPriceName";
            this.labCurPriceName.Size = new System.Drawing.Size(129, 105);
            this.labCurPriceName.TabIndex = 4;
            this.labCurPriceName.Text = "현재가";
            this.labCurPriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelStockDayFirstName
            // 
            this.panelStockDayFirstName.Controls.Add(this.label1);
            this.panelStockDayFirstName.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelStockDayFirstName.Location = new System.Drawing.Point(0, 0);
            this.panelStockDayFirstName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelStockDayFirstName.Name = "panelStockDayFirstName";
            this.panelStockDayFirstName.Size = new System.Drawing.Size(617, 85);
            this.panelStockDayFirstName.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(617, 85);
            this.label1.TabIndex = 1;
            this.label1.Text = "네오팜";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panelStockDaySecondEvent
            // 
            this.panelStockDaySecondEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.panelStockDaySecondEvent.Location = new System.Drawing.Point(617, 38);
            this.panelStockDaySecondEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDaySecondEvent.Name = "panelStockDaySecondEvent";
            this.panelStockDaySecondEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDaySecondEvent.TabIndex = 1;
            // 
            // panelStockDayThirdEvent
            // 
            this.panelStockDayThirdEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.panelStockDayThirdEvent.Location = new System.Drawing.Point(0, 438);
            this.panelStockDayThirdEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDayThirdEvent.Name = "panelStockDayThirdEvent";
            this.panelStockDayThirdEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDayThirdEvent.TabIndex = 2;
            // 
            // panelStockDayFourthEvent
            // 
            this.panelStockDayFourthEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panelStockDayFourthEvent.Location = new System.Drawing.Point(617, 438);
            this.panelStockDayFourthEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDayFourthEvent.Name = "panelStockDayFourthEvent";
            this.panelStockDayFourthEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDayFourthEvent.TabIndex = 2;
            // 
            // butAddEvent
            // 
            this.butAddEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.butAddEvent.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butAddEvent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butAddEvent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.butAddEvent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butAddEvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.butAddEvent.ForeColor = System.Drawing.Color.White;
            this.butAddEvent.Location = new System.Drawing.Point(487, 4);
            this.butAddEvent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butAddEvent.Name = "butAddEvent";
            this.butAddEvent.Size = new System.Drawing.Size(129, 32);
            this.butAddEvent.TabIndex = 1;
            this.butAddEvent.TabStop = false;
            this.butAddEvent.Text = "종목추가";
            this.butAddEvent.UseVisualStyleBackColor = false;
            this.butAddEvent.Click += new System.EventHandler(this.butAddEvent_Click);
            // 
            // butDelEvent
            // 
            this.butDelEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.butDelEvent.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butDelEvent.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butDelEvent.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.butDelEvent.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butDelEvent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.butDelEvent.ForeColor = System.Drawing.Color.White;
            this.butDelEvent.Location = new System.Drawing.Point(618, 4);
            this.butDelEvent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butDelEvent.Name = "butDelEvent";
            this.butDelEvent.Size = new System.Drawing.Size(129, 32);
            this.butDelEvent.TabIndex = 3;
            this.butDelEvent.TabStop = false;
            this.butDelEvent.Text = "종목삭제";
            this.butDelEvent.UseVisualStyleBackColor = false;
            // 
            // StockDayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClientSize = new System.Drawing.Size(1234, 838);
            this.Controls.Add(this.butDelEvent);
            this.Controls.Add(this.butAddEvent);
            this.Controls.Add(this.panelStockDayFourthEvent);
            this.Controls.Add(this.panelStockDayThirdEvent);
            this.Controls.Add(this.panelStockDaySecondEvent);
            this.Controls.Add(this.panelStockDayFirstEvent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "StockDayForm";
            this.Text = "StockDayForm";
            this.Load += new System.EventHandler(this.StockDayForm_Load);
            this.panelStockDayFirstEvent.ResumeLayout(false);
            this.panelBeforePrice.ResumeLayout(false);
            this.panelCurPrice.ResumeLayout(false);
            this.panelStockDayFirstName.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelStockDayFirstEvent;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panelStockDaySecondEvent;
        private System.Windows.Forms.Panel panelStockDayThirdEvent;
        private System.Windows.Forms.Panel panelStockDayFourthEvent;
        private System.Windows.Forms.Panel panelStockDayFirstName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butAddEvent;
        private System.Windows.Forms.Button butDelEvent;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelBeforePrice;
        private System.Windows.Forms.Panel panelCurPrice;
        private System.Windows.Forms.Label labCurPriceName;
        private System.Windows.Forms.Label labBeforePriceName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labCurPrice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}