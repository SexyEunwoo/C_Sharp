﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOME_IOT_NEW_SKIN
{
    public class Stock
    {
        enum XML_ORDER { DATE, CUR, HIGH, LOW, END};
        private string name;                            // 주식 이름
        private string date;                              // 주식 가격 날짜
        private string curPrice;                        // 주식 현재가격
        private string highPrice;                      // 주식 고가
        private string lowPrice;                       // 주식 저가
        private string endPriceYesterday;       // 주식 어제 종가
        private string purchasePrice;              // 한 주당 구매 단가
        private int count;                                 // 소유 주식 개수
        private float margin;                            // 이윤

        public Stock()
        {
            name = null;
            date = null;
            curPrice = null;
            highPrice = null;
            lowPrice = null;
            endPriceYesterday = null;
            purchasePrice = null;
            count = 0;
            margin = 0;
        }

        public void SetPrice(string stockName, string xmlStr, string purPrice, int cnt)
        {
            if (xmlStr.Substring(0, 10).CompareTo("<item data") != 0)
                return;

            // 주식 가격과 |문자만 남기고 앞뒤 자르기
            string price = xmlStr.Substring(12);
            price = price.Remove(price.Length - 4, 4);
            string[] prices = price.Split('|');

            // 주식 정보 설정
            this.name = stockName;
            this.date = prices[OrderToInt(XML_ORDER.DATE)];
            this.curPrice = prices[OrderToInt(XML_ORDER.CUR)];
            this.highPrice = prices[OrderToInt(XML_ORDER.HIGH)];
            this.lowPrice = prices[OrderToInt(XML_ORDER.LOW)];
            this.endPriceYesterday = prices[OrderToInt(XML_ORDER.END)];
            this.purchasePrice = purPrice;
            this.count = cnt;

            // 현재 이윤 설정( 현재1주당 가격 / 구매1주당 가격 )
            this.margin = Convert.ToInt32(this.curPrice) / Convert.ToInt32(this.purchasePrice);
        }

        public void Update(string xmlStr)
        {

        }

        public string CurPrice
        {
            get { return this.curPrice; }
        }

        public string HighPrice
        {
            get { return this.highPrice; }
        }

        public string LowPrice
        {
            get { return this.lowPrice; }
        }

        public string EndPriceYesterday
        {
            get { return this.endPriceYesterday; }
        }

        public string PurchasePrice
        {
            get { return this.purchasePrice; }
        }

        public int Count
        {
            get { return this.count; }
        }

        public float Margin
        {
            get { return this.margin; }
        }

        private int OrderToInt(XML_ORDER order)
        {
            return (int)order;
        }

    }
}
