﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class ModbusTCP_Parser
    {
        private enum FUNCTION_CODE
        {
            NONE,
            READ_COILES,
            READ_DISCRETE_INPUTS,
            READ_MULTI_HREG,
            READ_INPUT_REG,
            WRITE_SINGLE_COIL,
            WRITE_SINGLE_HREG,
            WRITE_MULTIPLE_COILS = 15,
            WRITE_MULTI_HREGS = 16
        };
        private struct MBAP
        {
            public ushort tid;
            public ushort pid;
            public ushort length;
            public byte uid;
        };


    }
}
