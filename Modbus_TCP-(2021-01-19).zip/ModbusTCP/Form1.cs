﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private const int LOOP_MIN_MILLIS = 100;

        private struct MBAP
        {
            public ushort tid;
            public ushort pid;
            public ushort length;
            public byte uid;
        };
        private enum FUNCTION_CODE
        {
            NONE,
            READ_COILES,
            READ_DISCRETE_INPUTS,
            READ_MULTI_HREG,
            READ_INPUT_REG,
            WRITE_SINGLE_COIL,
            WRITE_SINGLE_HREG,
            WRITE_MULTIPLE_COILS = 15,
            WRITE_MULTI_HREGS = 16
        };

        private ushort startAddr;
        private ushort length;
        private byte byteCount;

        private byte[] send_data;
        private byte[] read_data;
        private Socket sock;
        private bool isConnected;
        private string ip;
        private int port;

        private MBAP mbap;
        private byte funcCode;

        private System.Threading.Timer sock_timer;
        private System.Threading.Timer loop;
        private Point mousePoint;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sock_timer = new System.Threading.Timer(sock_Timer_Callback, null, 0, 40);

            mbap = new MBAP();
            mbap.tid = 0x00;
            mbap.pid = 0x00;
            mbap.uid = 0x01;

            send_data = new byte[255];
            read_data = new byte[255];
            funcCode = 0x00;
            groupBox_ButtonData.Enabled = false;
            groupBox_Datas.Enabled = false;
            groupBox_Loop.Enabled = false;
            but_LoopStop.BackColor = Color.FromArgb(90, 90, 90);

            radio_DEC.Checked = true;
        }

        private void but_Connect_Click(object sender, EventArgs e)
        {
            if(text_IP.Text == "" || text_Port.Text == "")
            {
                MessageBox.Show("IP주소와 PORT번호를 적으십시오", "ERROR");
                return;
            }

            if(isConnected)
            {
                string err = string.Format("이미 연결되어 있습니다 {0}", ip);
                MessageBox.Show(err, "ERROR");
                return;
            }
            ip = text_IP.Text;
            port = Convert.ToInt32(text_Port.Text);

            try
            {
                sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                sock.Connect(ip, port);
                isConnected = true;
            }
            catch(Exception ex)
            {
                string err = string.Format("Error : {0}", ex.Message);
                MessageBox.Show(err);
                return;
            }

            lab_ConnectionStatus.Text = "Connected";

            groupBox_ButtonData.Enabled = true;
            groupBox_Datas.Enabled = true;
            groupBox_Loop.Enabled = true;
        }

        private void but_Disconnect_Click(object sender, EventArgs e)
        {
            if(sock.Connected)
            {
                sock.Dispose();
                lab_ConnectionStatus.Text = "Disconnected";
                isConnected = false;

                groupBox_ButtonData.Enabled = false;
                groupBox_Datas.Enabled = false;
                groupBox_Loop.Enabled = false;
            }
            else
            {
                MessageBox.Show("You're not connected");
            }
        }

        private void but_ReadHreg_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.READ_MULTI_HREG;
            text_Data.Enabled = false;
            set_Cur_Func();
        }

        private void but_ReadCoil_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.READ_COILES;
            text_Data.Enabled = false;
            set_Cur_Func();
        }

        private void but_WriteHreg_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.WRITE_MULTI_HREGS;
            text_Data.Enabled = true;
            set_Cur_Func();
        }

        private void but_WriteCoil_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS;
            text_Data.Enabled = true;
            set_Cur_Func();
        }

        private void set_Cur_Func()
        {
            switch(funcCode)
            {
                case (byte)FUNCTION_CODE.READ_COILES:
                case (byte)FUNCTION_CODE.READ_DISCRETE_INPUTS:
                    lab_CurrentFunc.Text = "ReadCoil";
                    break;
                case (byte)FUNCTION_CODE.READ_MULTI_HREG:
                case (byte)FUNCTION_CODE.READ_INPUT_REG:
                    lab_CurrentFunc.Text = "ReadHreg";
                    break;
                case (byte)FUNCTION_CODE.WRITE_SINGLE_COIL:
                case (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS:
                    lab_CurrentFunc.Text = "WriteCoil";
                    break;
                case (byte)FUNCTION_CODE.WRITE_SINGLE_HREG:
                case (byte)FUNCTION_CODE.WRITE_MULTI_HREGS:
                    lab_CurrentFunc.Text = "WriteHreg";
                    break;
                case (byte)FUNCTION_CODE.NONE:
                    lab_CurrentFunc.Text = "NONE";
                    break;
            }
        }

        private void but_Send_Click(object sender, EventArgs e)
        {
            if(funcCode == (byte)FUNCTION_CODE.NONE)
            {
                MessageBox.Show("동작방식을 선택하십시오", "Error");
                return;
            }

            if(text_StartAddr.Text == "" || text_Length.Text == "")
            {
                MessageBox.Show("시작주소 또는 길이가 누락되었습니다.", "Error");
                return;
            }

            send();
        }

        private void send()
        {
            text_RcevData.Text = "";
            text_SendData.Text = "";
            string[] str_data;
            int size = 0;

            size = 7; // MBAP Length

            switch (funcCode)
            {

                case (byte)FUNCTION_CODE.READ_COILES:
                case (byte)FUNCTION_CODE.READ_DISCRETE_INPUTS:
                case (byte)FUNCTION_CODE.READ_MULTI_HREG:
                case (byte)FUNCTION_CODE.READ_INPUT_REG:

                    startAddr = string_To_Number(text_StartAddr.Text);
                    if (startAddr == UInt16.MaxValue)
                        return;

                    length = string_To_Number(text_Length.Text);
                    if (length == UInt16.MaxValue)
                        return;

                    mbap.length = 0x06;
                    send_data[0] = (byte)(mbap.tid >> 8);
                    send_data[1] = (byte)mbap.tid;
                    send_data[2] = (byte)(mbap.pid >> 8);
                    send_data[3] = (byte)mbap.pid;
                    send_data[4] = (byte)(mbap.length >> 8);
                    send_data[5] = (byte)mbap.length;
                    send_data[6] = mbap.uid;

                    send_data[size] = funcCode;
                    size += sizeof(byte);       // FuncCode Length

                    send_data[size] = (byte)(startAddr >> 8);
                    send_data[size+1] = (byte)startAddr;
                    size += sizeof(ushort);    // Start Address Length

                    send_data[size] = (byte)(length >> 8);
                    send_data[size+1] = (byte)length;
                    size += sizeof(ushort); // Read Length

                    break;

                case (byte)FUNCTION_CODE.WRITE_SINGLE_HREG:
                case (byte)FUNCTION_CODE.WRITE_MULTI_HREGS:

                    startAddr = string_To_Number(text_StartAddr.Text);  // returns string to dec or hex 
                    if (startAddr == UInt16.MaxValue)
                        return;

                    length = string_To_Number(text_Length.Text); // returns string to dec or hex 
                    if (length == UInt16.MaxValue || length > 127)
                        return;

                    byteCount = (byte)(length * 2);

                    str_data = text_Data.Text.Split(' ');
                    if(str_data.Length < length)
                    {
                        string str = string.Format("Error : Require {0}data, Read only {1}data", length, str_data.Length);
                        MessageBox.Show(str);
                    }

                    mbap.length = 0x07; // Unit ID, StartAddr, Length, DataByteLength
                    mbap.length += byteCount;
                    send_data[0] = (byte)(mbap.tid >> 8);
                    send_data[1] = (byte)mbap.tid;
                    send_data[2] = (byte)(mbap.pid >> 8);
                    send_data[3] = (byte)mbap.pid;
                    send_data[4] = (byte)(mbap.length >> 8);
                    send_data[5] = (byte)mbap.length;
                    send_data[6] = mbap.uid;

                    send_data[size++] = funcCode;

                    send_data[size++] = (byte)(startAddr >> 8);
                    send_data[size++] = (byte)(startAddr);

                    send_data[size++] = (byte)(length >> 8);
                    send_data[size++] = (byte)length;

                    send_data[size++] = byteCount;

                    for (int i = 0; i < str_data.Length; i++)
                    {
                        ushort temp = string_To_Number(str_data[i]);
                        send_data[size++] = (byte)(temp >> 8);
                        send_data[size++] = (byte)temp;
                    }
                    break;

                case (byte)FUNCTION_CODE.WRITE_SINGLE_COIL:
                case (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS:

                    startAddr = string_To_Number(text_StartAddr.Text);  // returns string to dec or hex 
                    if (startAddr == UInt16.MaxValue)
                        return;

                    length = string_To_Number(text_Length.Text); // returns string to dec or hex 
                    if (length == UInt16.MaxValue || length > 127)
                        return;

                    byteCount = (byte)((length / (4 + 1)) + 1);
                    byte tempData = (byte)(string_To_Number(text_Data.Text) >> 8);

                    str_data = text_Data.Text.Split(' ');
                    if (str_data.Length < byteCount)
                    {
                        string str = string.Format("Error : Require {0}data, Read only {1}data", byteCount, str_data.Length);
                        MessageBox.Show(str);
                        return;
                    }


                    mbap.length = 0x07; // Unit ID, StartAddr, Length, DataByteLength
                    mbap.length += byteCount;
                    send_data[0] = (byte)(mbap.tid >> 8);
                    send_data[1] = (byte)mbap.tid;
                    send_data[2] = (byte)(mbap.pid >> 8);
                    send_data[3] = (byte)mbap.pid;
                    send_data[4] = (byte)(mbap.length >> 8);
                    send_data[5] = (byte)mbap.length;
                    send_data[6] = mbap.uid;

                    send_data[size++] = funcCode;

                    send_data[size++] = (byte)(startAddr >> 8);
                    send_data[size++] = (byte)(startAddr);

                    send_data[size++] = (byte)(length >> 8);
                    send_data[size++] = (byte)length;

                    send_data[size++] = byteCount;

                    for (int i = 0; i < str_data.Length; i++)
                    {
                        ushort temp = string_To_Number(str_data[i]);
                        send_data[size++] = (byte)temp;
                    }

                    break;
            }

            for(int i = 0; i < size; i++)
            {
                text_SendData.Text += send_data[i].ToString("X2") + " ";
            }

            sock.Send(send_data, size, SocketFlags.None);
        }

        private void sock_Timer_Callback(object state)
        {
            if(sock == null || !sock.Connected)
            {
                return;
            }
            Invoke(new MethodInvoker(delegate ()
            {
                if(sock.Available > 0)
                {
                    int len = sock.Available;
                    int read_len = sock.Receive(read_data, len, SocketFlags.None);

                    for(int i = 0; i < len; i++)
                    {
                        text_RcevData.AppendText(read_data[i].ToString("X2") + " ");
                    }
                    string str = string.Format("{0} >> ", DateTime.Now.ToString("HH:mm:ss"));
                    richText_Recv.Text += str;
                    for(int i = 0; i < read_len; i++)
                    {
                        richText_Recv.AppendText(read_data[i].ToString("X2") + " ");
                    }
                    richText_Recv.AppendText("\n");

                    richText_Recv.ScrollToCaret();
                }
            }));
        }

        private ushort string_To_Number(string str)
        {
            try
            {
                if (radio_HEX.Checked)
                {
                    return Convert.ToUInt16(str, 16);
                }
                else
                {
                    return Convert.ToUInt16(str, 10);
                }
            }
            catch(Exception excep)
            {
                string err = string.Format("Error : {0}", excep.Message);
                MessageBox.Show(err, "Error");
            }

            return UInt16.MaxValue;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mousePoint = new Point(e.X, e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                int x = mousePoint.X - e.X;
                int y = mousePoint.Y - e.Y;
                Location = new Point(this.Left - x, this.Top - y);
            }
        }

        private void but_LoopStart_Click(object sender, EventArgs e)
        {
            if(text_Interval.Text == "")
            {
                MessageBox.Show("Interval bos is empty", "Erorr");
                return;
            }

            int millis = Convert.ToInt32(text_Interval.Text);
            if (millis < LOOP_MIN_MILLIS)
            {
                MessageBox.Show("Min loop interval is 100ms", "Error");
                return;
            }


            loop = new System.Threading.Timer(loop_Callback, 0, 0, millis);


            but_LoopStart.BackColor = Color.FromArgb(90, 90, 90);
            but_LoopStart.Enabled = false;

            but_LoopStop.BackColor = Color.FromArgb(50, 50, 50);
            but_LoopStop.Enabled = true;

            lab_LoopStatusDisplay.Text = "LOOP";
        }

        private void loop_Callback(object state)
        {
            if (this.InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate ()
                {
                    but_Send_Click(null, null);
                }));
            }
        }

        private void but_LoopStop_Click(object sender, EventArgs e)
        {
            if(loop != null)
            {
                loop.Dispose();
            }

            but_LoopStop.BackColor = Color.FromArgb(90, 90, 90);
            but_LoopStop.Enabled = false;

            but_LoopStart.BackColor = Color.FromArgb(50, 50, 50);
            but_LoopStart.Enabled = true;

            lab_LoopStatusDisplay.Text = "STOP";
        }
    }
}
