﻿namespace HOME_IOT_NEW_SKIN
{
    partial class StockDayForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelStockDayFirstEvent = new System.Windows.Forms.Panel();
            this.panelFirstStockBlank1 = new System.Windows.Forms.Panel();
            this.labFirstStockBenefitFigure = new System.Windows.Forms.Label();
            this.labFirstStockBenefitName = new System.Windows.Forms.Label();
            this.panelFirstStockBeforePrice = new System.Windows.Forms.Panel();
            this.labFirstStockBuyPrice = new System.Windows.Forms.Label();
            this.labFirstStockBuyPriceName = new System.Windows.Forms.Label();
            this.labFirstStockBeforePrice = new System.Windows.Forms.Label();
            this.labFirstStockBeforePriceName = new System.Windows.Forms.Label();
            this.panelFirstStockCurPrice = new System.Windows.Forms.Panel();
            this.labFirstStockCurFluctuationRate = new System.Windows.Forms.Label();
            this.labFirstStockCurFluctuation = new System.Windows.Forms.Label();
            this.labFirstStockCurPrice = new System.Windows.Forms.Label();
            this.labFirstStockCurPriceName = new System.Windows.Forms.Label();
            this.panelStockDayFirstName = new System.Windows.Forms.Panel();
            this.labFirstStockName = new System.Windows.Forms.Label();
            this.timerFirstStock = new System.Windows.Forms.Timer(this.components);
            this.panelStockDaySecondEvent = new System.Windows.Forms.Panel();
            this.labSecondStockBenefitFigure = new System.Windows.Forms.Label();
            this.labSecondStockBenefitName = new System.Windows.Forms.Label();
            this.panelSecondStockBeforePrice = new System.Windows.Forms.Panel();
            this.labSecondStockBuyPrice = new System.Windows.Forms.Label();
            this.labSecondStockBuyPriceName = new System.Windows.Forms.Label();
            this.labSecondStockBeforePrice = new System.Windows.Forms.Label();
            this.labSecondStockBeforePriceName = new System.Windows.Forms.Label();
            this.panelSecondStockCurPrice = new System.Windows.Forms.Panel();
            this.labSecondStockCurFluctuationRate = new System.Windows.Forms.Label();
            this.labSecondStockCurFluctuation = new System.Windows.Forms.Label();
            this.labSecondStockCurPrice = new System.Windows.Forms.Label();
            this.labSecondStockCurPriceName = new System.Windows.Forms.Label();
            this.labSecondStockName = new System.Windows.Forms.Label();
            this.panelStockDayThirdEvent = new System.Windows.Forms.Panel();
            this.labThirdStockName = new System.Windows.Forms.Label();
            this.panelStockDayFourthEvent = new System.Windows.Forms.Panel();
            this.labFourthStockName = new System.Windows.Forms.Label();
            this.butAdd = new System.Windows.Forms.Button();
            this.butDel = new System.Windows.Forms.Button();
            this.butBuyStock = new System.Windows.Forms.Button();
            this.butSellStock = new System.Windows.Forms.Button();
            this.timerSecondStock = new System.Windows.Forms.Timer(this.components);
            this.timerThirdStock = new System.Windows.Forms.Timer(this.components);
            this.timerFourthStock = new System.Windows.Forms.Timer(this.components);
            this.panelStockDayFirstEvent.SuspendLayout();
            this.panelFirstStockBlank1.SuspendLayout();
            this.panelFirstStockBeforePrice.SuspendLayout();
            this.panelFirstStockCurPrice.SuspendLayout();
            this.panelStockDayFirstName.SuspendLayout();
            this.panelStockDaySecondEvent.SuspendLayout();
            this.panelSecondStockBeforePrice.SuspendLayout();
            this.panelSecondStockCurPrice.SuspendLayout();
            this.panelStockDayThirdEvent.SuspendLayout();
            this.panelStockDayFourthEvent.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelStockDayFirstEvent
            // 
            this.panelStockDayFirstEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panelStockDayFirstEvent.Controls.Add(this.panelFirstStockBlank1);
            this.panelStockDayFirstEvent.Controls.Add(this.panelFirstStockBeforePrice);
            this.panelStockDayFirstEvent.Controls.Add(this.panelFirstStockCurPrice);
            this.panelStockDayFirstEvent.Controls.Add(this.panelStockDayFirstName);
            this.panelStockDayFirstEvent.Location = new System.Drawing.Point(0, 38);
            this.panelStockDayFirstEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDayFirstEvent.Name = "panelStockDayFirstEvent";
            this.panelStockDayFirstEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDayFirstEvent.TabIndex = 0;
            // 
            // panelFirstStockBlank1
            // 
            this.panelFirstStockBlank1.Controls.Add(this.labFirstStockBenefitFigure);
            this.panelFirstStockBlank1.Controls.Add(this.labFirstStockBenefitName);
            this.panelFirstStockBlank1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFirstStockBlank1.Location = new System.Drawing.Point(0, 295);
            this.panelFirstStockBlank1.Margin = new System.Windows.Forms.Padding(0);
            this.panelFirstStockBlank1.Name = "panelFirstStockBlank1";
            this.panelFirstStockBlank1.Size = new System.Drawing.Size(617, 105);
            this.panelFirstStockBlank1.TabIndex = 3;
            // 
            // labFirstStockBenefitFigure
            // 
            this.labFirstStockBenefitFigure.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockBenefitFigure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labFirstStockBenefitFigure.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFirstStockBenefitFigure.ForeColor = System.Drawing.Color.Lime;
            this.labFirstStockBenefitFigure.Location = new System.Drawing.Point(190, 0);
            this.labFirstStockBenefitFigure.Name = "labFirstStockBenefitFigure";
            this.labFirstStockBenefitFigure.Size = new System.Drawing.Size(427, 105);
            this.labFirstStockBenefitFigure.TabIndex = 7;
            this.labFirstStockBenefitFigure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labFirstStockBenefitName
            // 
            this.labFirstStockBenefitName.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockBenefitName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockBenefitName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFirstStockBenefitName.ForeColor = System.Drawing.Color.Lime;
            this.labFirstStockBenefitName.Location = new System.Drawing.Point(0, 0);
            this.labFirstStockBenefitName.Name = "labFirstStockBenefitName";
            this.labFirstStockBenefitName.Size = new System.Drawing.Size(190, 105);
            this.labFirstStockBenefitName.TabIndex = 6;
            this.labFirstStockBenefitName.Text = "수익";
            this.labFirstStockBenefitName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labFirstStockBenefitName.Visible = false;
            // 
            // panelFirstStockBeforePrice
            // 
            this.panelFirstStockBeforePrice.Controls.Add(this.labFirstStockBuyPrice);
            this.panelFirstStockBeforePrice.Controls.Add(this.labFirstStockBuyPriceName);
            this.panelFirstStockBeforePrice.Controls.Add(this.labFirstStockBeforePrice);
            this.panelFirstStockBeforePrice.Controls.Add(this.labFirstStockBeforePriceName);
            this.panelFirstStockBeforePrice.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFirstStockBeforePrice.Location = new System.Drawing.Point(0, 190);
            this.panelFirstStockBeforePrice.Margin = new System.Windows.Forms.Padding(0);
            this.panelFirstStockBeforePrice.Name = "panelFirstStockBeforePrice";
            this.panelFirstStockBeforePrice.Size = new System.Drawing.Size(617, 105);
            this.panelFirstStockBeforePrice.TabIndex = 2;
            // 
            // labFirstStockBuyPrice
            // 
            this.labFirstStockBuyPrice.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockBuyPrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockBuyPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.labFirstStockBuyPrice.ForeColor = System.Drawing.Color.White;
            this.labFirstStockBuyPrice.Location = new System.Drawing.Point(457, 0);
            this.labFirstStockBuyPrice.Name = "labFirstStockBuyPrice";
            this.labFirstStockBuyPrice.Size = new System.Drawing.Size(168, 105);
            this.labFirstStockBuyPrice.TabIndex = 10;
            this.labFirstStockBuyPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labFirstStockBuyPriceName
            // 
            this.labFirstStockBuyPriceName.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockBuyPriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockBuyPriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.labFirstStockBuyPriceName.ForeColor = System.Drawing.Color.White;
            this.labFirstStockBuyPriceName.Location = new System.Drawing.Point(288, 0);
            this.labFirstStockBuyPriceName.Name = "labFirstStockBuyPriceName";
            this.labFirstStockBuyPriceName.Size = new System.Drawing.Size(169, 105);
            this.labFirstStockBuyPriceName.TabIndex = 9;
            this.labFirstStockBuyPriceName.Text = "구매가     주식개수";
            this.labFirstStockBuyPriceName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labFirstStockBuyPriceName.Visible = false;
            // 
            // labFirstStockBeforePrice
            // 
            this.labFirstStockBeforePrice.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockBeforePrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockBeforePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFirstStockBeforePrice.ForeColor = System.Drawing.Color.White;
            this.labFirstStockBeforePrice.Location = new System.Drawing.Point(129, 0);
            this.labFirstStockBeforePrice.Name = "labFirstStockBeforePrice";
            this.labFirstStockBeforePrice.Size = new System.Drawing.Size(159, 105);
            this.labFirstStockBeforePrice.TabIndex = 8;
            this.labFirstStockBeforePrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labFirstStockBeforePriceName
            // 
            this.labFirstStockBeforePriceName.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockBeforePriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockBeforePriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFirstStockBeforePriceName.ForeColor = System.Drawing.Color.White;
            this.labFirstStockBeforePriceName.Location = new System.Drawing.Point(0, 0);
            this.labFirstStockBeforePriceName.Name = "labFirstStockBeforePriceName";
            this.labFirstStockBeforePriceName.Size = new System.Drawing.Size(129, 105);
            this.labFirstStockBeforePriceName.TabIndex = 5;
            this.labFirstStockBeforePriceName.Text = "전일가";
            this.labFirstStockBeforePriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labFirstStockBeforePriceName.Visible = false;
            // 
            // panelFirstStockCurPrice
            // 
            this.panelFirstStockCurPrice.Controls.Add(this.labFirstStockCurFluctuationRate);
            this.panelFirstStockCurPrice.Controls.Add(this.labFirstStockCurFluctuation);
            this.panelFirstStockCurPrice.Controls.Add(this.labFirstStockCurPrice);
            this.panelFirstStockCurPrice.Controls.Add(this.labFirstStockCurPriceName);
            this.panelFirstStockCurPrice.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFirstStockCurPrice.Location = new System.Drawing.Point(0, 85);
            this.panelFirstStockCurPrice.Margin = new System.Windows.Forms.Padding(0);
            this.panelFirstStockCurPrice.Name = "panelFirstStockCurPrice";
            this.panelFirstStockCurPrice.Size = new System.Drawing.Size(617, 105);
            this.panelFirstStockCurPrice.TabIndex = 1;
            // 
            // labFirstStockCurFluctuationRate
            // 
            this.labFirstStockCurFluctuationRate.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockCurFluctuationRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labFirstStockCurFluctuationRate.ForeColor = System.Drawing.Color.Red;
            this.labFirstStockCurFluctuationRate.Location = new System.Drawing.Point(290, 52);
            this.labFirstStockCurFluctuationRate.Name = "labFirstStockCurFluctuationRate";
            this.labFirstStockCurFluctuationRate.Size = new System.Drawing.Size(145, 55);
            this.labFirstStockCurFluctuationRate.TabIndex = 7;
            this.labFirstStockCurFluctuationRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labFirstStockCurFluctuation
            // 
            this.labFirstStockCurFluctuation.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockCurFluctuation.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labFirstStockCurFluctuation.ForeColor = System.Drawing.Color.Red;
            this.labFirstStockCurFluctuation.Location = new System.Drawing.Point(290, 0);
            this.labFirstStockCurFluctuation.Name = "labFirstStockCurFluctuation";
            this.labFirstStockCurFluctuation.Size = new System.Drawing.Size(143, 52);
            this.labFirstStockCurFluctuation.TabIndex = 6;
            this.labFirstStockCurFluctuation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labFirstStockCurPrice
            // 
            this.labFirstStockCurPrice.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockCurPrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockCurPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFirstStockCurPrice.ForeColor = System.Drawing.Color.White;
            this.labFirstStockCurPrice.Location = new System.Drawing.Point(129, 0);
            this.labFirstStockCurPrice.Name = "labFirstStockCurPrice";
            this.labFirstStockCurPrice.Size = new System.Drawing.Size(159, 105);
            this.labFirstStockCurPrice.TabIndex = 5;
            this.labFirstStockCurPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labFirstStockCurPriceName
            // 
            this.labFirstStockCurPriceName.BackColor = System.Drawing.Color.Transparent;
            this.labFirstStockCurPriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labFirstStockCurPriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labFirstStockCurPriceName.ForeColor = System.Drawing.Color.White;
            this.labFirstStockCurPriceName.Location = new System.Drawing.Point(0, 0);
            this.labFirstStockCurPriceName.Name = "labFirstStockCurPriceName";
            this.labFirstStockCurPriceName.Size = new System.Drawing.Size(129, 105);
            this.labFirstStockCurPriceName.TabIndex = 4;
            this.labFirstStockCurPriceName.Text = "현재가";
            this.labFirstStockCurPriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labFirstStockCurPriceName.Visible = false;
            // 
            // panelStockDayFirstName
            // 
            this.panelStockDayFirstName.Controls.Add(this.labFirstStockName);
            this.panelStockDayFirstName.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelStockDayFirstName.Location = new System.Drawing.Point(0, 0);
            this.panelStockDayFirstName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelStockDayFirstName.Name = "panelStockDayFirstName";
            this.panelStockDayFirstName.Size = new System.Drawing.Size(617, 85);
            this.panelStockDayFirstName.TabIndex = 0;
            // 
            // labFirstStockName
            // 
            this.labFirstStockName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labFirstStockName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labFirstStockName.ForeColor = System.Drawing.Color.White;
            this.labFirstStockName.Location = new System.Drawing.Point(0, 0);
            this.labFirstStockName.Name = "labFirstStockName";
            this.labFirstStockName.Size = new System.Drawing.Size(617, 85);
            this.labFirstStockName.TabIndex = 1;
            this.labFirstStockName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timerFirstStock
            // 
            this.timerFirstStock.Enabled = true;
            this.timerFirstStock.Interval = 5000;
            this.timerFirstStock.Tick += new System.EventHandler(this.timerFirstStock_Tick);
            // 
            // panelStockDaySecondEvent
            // 
            this.panelStockDaySecondEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.panelStockDaySecondEvent.Controls.Add(this.labSecondStockBenefitFigure);
            this.panelStockDaySecondEvent.Controls.Add(this.labSecondStockBenefitName);
            this.panelStockDaySecondEvent.Controls.Add(this.panelSecondStockBeforePrice);
            this.panelStockDaySecondEvent.Controls.Add(this.panelSecondStockCurPrice);
            this.panelStockDaySecondEvent.Controls.Add(this.labSecondStockName);
            this.panelStockDaySecondEvent.Location = new System.Drawing.Point(617, 38);
            this.panelStockDaySecondEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDaySecondEvent.Name = "panelStockDaySecondEvent";
            this.panelStockDaySecondEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDaySecondEvent.TabIndex = 1;
            // 
            // labSecondStockBenefitFigure
            // 
            this.labSecondStockBenefitFigure.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockBenefitFigure.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labSecondStockBenefitFigure.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSecondStockBenefitFigure.ForeColor = System.Drawing.Color.Lime;
            this.labSecondStockBenefitFigure.Location = new System.Drawing.Point(190, 295);
            this.labSecondStockBenefitFigure.Name = "labSecondStockBenefitFigure";
            this.labSecondStockBenefitFigure.Size = new System.Drawing.Size(427, 105);
            this.labSecondStockBenefitFigure.TabIndex = 8;
            this.labSecondStockBenefitFigure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSecondStockBenefitName
            // 
            this.labSecondStockBenefitName.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockBenefitName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockBenefitName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSecondStockBenefitName.ForeColor = System.Drawing.Color.Lime;
            this.labSecondStockBenefitName.Location = new System.Drawing.Point(0, 295);
            this.labSecondStockBenefitName.Name = "labSecondStockBenefitName";
            this.labSecondStockBenefitName.Size = new System.Drawing.Size(190, 105);
            this.labSecondStockBenefitName.TabIndex = 7;
            this.labSecondStockBenefitName.Text = "수익";
            this.labSecondStockBenefitName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labSecondStockBenefitName.Visible = false;
            // 
            // panelSecondStockBeforePrice
            // 
            this.panelSecondStockBeforePrice.Controls.Add(this.labSecondStockBuyPrice);
            this.panelSecondStockBeforePrice.Controls.Add(this.labSecondStockBuyPriceName);
            this.panelSecondStockBeforePrice.Controls.Add(this.labSecondStockBeforePrice);
            this.panelSecondStockBeforePrice.Controls.Add(this.labSecondStockBeforePriceName);
            this.panelSecondStockBeforePrice.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSecondStockBeforePrice.Location = new System.Drawing.Point(0, 190);
            this.panelSecondStockBeforePrice.Margin = new System.Windows.Forms.Padding(0);
            this.panelSecondStockBeforePrice.Name = "panelSecondStockBeforePrice";
            this.panelSecondStockBeforePrice.Size = new System.Drawing.Size(617, 105);
            this.panelSecondStockBeforePrice.TabIndex = 4;
            // 
            // labSecondStockBuyPrice
            // 
            this.labSecondStockBuyPrice.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockBuyPrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockBuyPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.labSecondStockBuyPrice.ForeColor = System.Drawing.Color.White;
            this.labSecondStockBuyPrice.Location = new System.Drawing.Point(449, 0);
            this.labSecondStockBuyPrice.Name = "labSecondStockBuyPrice";
            this.labSecondStockBuyPrice.Size = new System.Drawing.Size(168, 105);
            this.labSecondStockBuyPrice.TabIndex = 10;
            this.labSecondStockBuyPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSecondStockBuyPriceName
            // 
            this.labSecondStockBuyPriceName.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockBuyPriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockBuyPriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.labSecondStockBuyPriceName.ForeColor = System.Drawing.Color.White;
            this.labSecondStockBuyPriceName.Location = new System.Drawing.Point(280, 0);
            this.labSecondStockBuyPriceName.Name = "labSecondStockBuyPriceName";
            this.labSecondStockBuyPriceName.Size = new System.Drawing.Size(169, 105);
            this.labSecondStockBuyPriceName.TabIndex = 9;
            this.labSecondStockBuyPriceName.Text = "구매가";
            this.labSecondStockBuyPriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labSecondStockBuyPriceName.Visible = false;
            // 
            // labSecondStockBeforePrice
            // 
            this.labSecondStockBeforePrice.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockBeforePrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockBeforePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSecondStockBeforePrice.ForeColor = System.Drawing.Color.White;
            this.labSecondStockBeforePrice.Location = new System.Drawing.Point(129, 0);
            this.labSecondStockBeforePrice.Name = "labSecondStockBeforePrice";
            this.labSecondStockBeforePrice.Size = new System.Drawing.Size(151, 105);
            this.labSecondStockBeforePrice.TabIndex = 8;
            this.labSecondStockBeforePrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSecondStockBeforePriceName
            // 
            this.labSecondStockBeforePriceName.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockBeforePriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockBeforePriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSecondStockBeforePriceName.ForeColor = System.Drawing.Color.White;
            this.labSecondStockBeforePriceName.Location = new System.Drawing.Point(0, 0);
            this.labSecondStockBeforePriceName.Name = "labSecondStockBeforePriceName";
            this.labSecondStockBeforePriceName.Size = new System.Drawing.Size(129, 105);
            this.labSecondStockBeforePriceName.TabIndex = 5;
            this.labSecondStockBeforePriceName.Text = "전일가";
            this.labSecondStockBeforePriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labSecondStockBeforePriceName.Visible = false;
            // 
            // panelSecondStockCurPrice
            // 
            this.panelSecondStockCurPrice.Controls.Add(this.labSecondStockCurFluctuationRate);
            this.panelSecondStockCurPrice.Controls.Add(this.labSecondStockCurFluctuation);
            this.panelSecondStockCurPrice.Controls.Add(this.labSecondStockCurPrice);
            this.panelSecondStockCurPrice.Controls.Add(this.labSecondStockCurPriceName);
            this.panelSecondStockCurPrice.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSecondStockCurPrice.Location = new System.Drawing.Point(0, 85);
            this.panelSecondStockCurPrice.Margin = new System.Windows.Forms.Padding(0);
            this.panelSecondStockCurPrice.Name = "panelSecondStockCurPrice";
            this.panelSecondStockCurPrice.Size = new System.Drawing.Size(617, 105);
            this.panelSecondStockCurPrice.TabIndex = 3;
            // 
            // labSecondStockCurFluctuationRate
            // 
            this.labSecondStockCurFluctuationRate.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockCurFluctuationRate.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labSecondStockCurFluctuationRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labSecondStockCurFluctuationRate.ForeColor = System.Drawing.Color.Red;
            this.labSecondStockCurFluctuationRate.Location = new System.Drawing.Point(280, 53);
            this.labSecondStockCurFluctuationRate.Name = "labSecondStockCurFluctuationRate";
            this.labSecondStockCurFluctuationRate.Size = new System.Drawing.Size(337, 52);
            this.labSecondStockCurFluctuationRate.TabIndex = 7;
            this.labSecondStockCurFluctuationRate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSecondStockCurFluctuation
            // 
            this.labSecondStockCurFluctuation.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockCurFluctuation.Dock = System.Windows.Forms.DockStyle.Top;
            this.labSecondStockCurFluctuation.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labSecondStockCurFluctuation.ForeColor = System.Drawing.Color.Red;
            this.labSecondStockCurFluctuation.Location = new System.Drawing.Point(280, 0);
            this.labSecondStockCurFluctuation.Name = "labSecondStockCurFluctuation";
            this.labSecondStockCurFluctuation.Size = new System.Drawing.Size(337, 52);
            this.labSecondStockCurFluctuation.TabIndex = 6;
            this.labSecondStockCurFluctuation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSecondStockCurPrice
            // 
            this.labSecondStockCurPrice.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockCurPrice.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockCurPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSecondStockCurPrice.ForeColor = System.Drawing.Color.White;
            this.labSecondStockCurPrice.Location = new System.Drawing.Point(129, 0);
            this.labSecondStockCurPrice.Name = "labSecondStockCurPrice";
            this.labSecondStockCurPrice.Size = new System.Drawing.Size(151, 105);
            this.labSecondStockCurPrice.TabIndex = 5;
            this.labSecondStockCurPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSecondStockCurPriceName
            // 
            this.labSecondStockCurPriceName.BackColor = System.Drawing.Color.Transparent;
            this.labSecondStockCurPriceName.Dock = System.Windows.Forms.DockStyle.Left;
            this.labSecondStockCurPriceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labSecondStockCurPriceName.ForeColor = System.Drawing.Color.White;
            this.labSecondStockCurPriceName.Location = new System.Drawing.Point(0, 0);
            this.labSecondStockCurPriceName.Name = "labSecondStockCurPriceName";
            this.labSecondStockCurPriceName.Size = new System.Drawing.Size(129, 105);
            this.labSecondStockCurPriceName.TabIndex = 4;
            this.labSecondStockCurPriceName.Text = "현재가";
            this.labSecondStockCurPriceName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labSecondStockCurPriceName.Visible = false;
            // 
            // labSecondStockName
            // 
            this.labSecondStockName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.labSecondStockName.Dock = System.Windows.Forms.DockStyle.Top;
            this.labSecondStockName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labSecondStockName.ForeColor = System.Drawing.Color.White;
            this.labSecondStockName.Location = new System.Drawing.Point(0, 0);
            this.labSecondStockName.Name = "labSecondStockName";
            this.labSecondStockName.Size = new System.Drawing.Size(617, 85);
            this.labSecondStockName.TabIndex = 2;
            this.labSecondStockName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelStockDayThirdEvent
            // 
            this.panelStockDayThirdEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.panelStockDayThirdEvent.Controls.Add(this.labThirdStockName);
            this.panelStockDayThirdEvent.Location = new System.Drawing.Point(0, 438);
            this.panelStockDayThirdEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDayThirdEvent.Name = "panelStockDayThirdEvent";
            this.panelStockDayThirdEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDayThirdEvent.TabIndex = 2;
            // 
            // labThirdStockName
            // 
            this.labThirdStockName.Dock = System.Windows.Forms.DockStyle.Top;
            this.labThirdStockName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labThirdStockName.ForeColor = System.Drawing.Color.White;
            this.labThirdStockName.Location = new System.Drawing.Point(0, 0);
            this.labThirdStockName.Name = "labThirdStockName";
            this.labThirdStockName.Size = new System.Drawing.Size(617, 85);
            this.labThirdStockName.TabIndex = 2;
            this.labThirdStockName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelStockDayFourthEvent
            // 
            this.panelStockDayFourthEvent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panelStockDayFourthEvent.Controls.Add(this.labFourthStockName);
            this.panelStockDayFourthEvent.Location = new System.Drawing.Point(617, 438);
            this.panelStockDayFourthEvent.Margin = new System.Windows.Forms.Padding(0);
            this.panelStockDayFourthEvent.Name = "panelStockDayFourthEvent";
            this.panelStockDayFourthEvent.Size = new System.Drawing.Size(617, 400);
            this.panelStockDayFourthEvent.TabIndex = 2;
            // 
            // labFourthStockName
            // 
            this.labFourthStockName.Dock = System.Windows.Forms.DockStyle.Top;
            this.labFourthStockName.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.labFourthStockName.ForeColor = System.Drawing.Color.White;
            this.labFourthStockName.Location = new System.Drawing.Point(0, 0);
            this.labFourthStockName.Name = "labFourthStockName";
            this.labFourthStockName.Size = new System.Drawing.Size(617, 85);
            this.labFourthStockName.TabIndex = 3;
            this.labFourthStockName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // butAdd
            // 
            this.butAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.butAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.butAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.butAdd.ForeColor = System.Drawing.Color.White;
            this.butAdd.Location = new System.Drawing.Point(357, 1);
            this.butAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(129, 35);
            this.butAdd.TabIndex = 1;
            this.butAdd.TabStop = false;
            this.butAdd.Text = "종목추가";
            this.butAdd.UseVisualStyleBackColor = false;
            this.butAdd.Click += new System.EventHandler(this.butAddEvent_Click);
            // 
            // butDel
            // 
            this.butDel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.butDel.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butDel.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butDel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.butDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butDel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.butDel.ForeColor = System.Drawing.Color.White;
            this.butDel.Location = new System.Drawing.Point(749, 1);
            this.butDel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butDel.Name = "butDel";
            this.butDel.Size = new System.Drawing.Size(129, 35);
            this.butDel.TabIndex = 3;
            this.butDel.TabStop = false;
            this.butDel.Text = "종목삭제";
            this.butDel.UseVisualStyleBackColor = false;
            this.butDel.Click += new System.EventHandler(this.butDel_Click);
            // 
            // butBuyStock
            // 
            this.butBuyStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.butBuyStock.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butBuyStock.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butBuyStock.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.butBuyStock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butBuyStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.butBuyStock.ForeColor = System.Drawing.Color.White;
            this.butBuyStock.Location = new System.Drawing.Point(488, 1);
            this.butBuyStock.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butBuyStock.Name = "butBuyStock";
            this.butBuyStock.Size = new System.Drawing.Size(129, 35);
            this.butBuyStock.TabIndex = 4;
            this.butBuyStock.TabStop = false;
            this.butBuyStock.Text = "종목구매";
            this.butBuyStock.UseVisualStyleBackColor = false;
            this.butBuyStock.Click += new System.EventHandler(this.butBuyStock_Click);
            // 
            // butSellStock
            // 
            this.butSellStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.butSellStock.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.butSellStock.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSellStock.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(120)))), ((int)(((byte)(120)))), ((int)(((byte)(120)))));
            this.butSellStock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSellStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.butSellStock.ForeColor = System.Drawing.Color.White;
            this.butSellStock.Location = new System.Drawing.Point(618, 1);
            this.butSellStock.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butSellStock.Name = "butSellStock";
            this.butSellStock.Size = new System.Drawing.Size(129, 35);
            this.butSellStock.TabIndex = 5;
            this.butSellStock.TabStop = false;
            this.butSellStock.Text = "종목판매";
            this.butSellStock.UseVisualStyleBackColor = false;
            this.butSellStock.Click += new System.EventHandler(this.butSellStock_Click);
            // 
            // timerSecondStock
            // 
            this.timerSecondStock.Enabled = true;
            this.timerSecondStock.Interval = 5000;
            this.timerSecondStock.Tick += new System.EventHandler(this.timerSecondStock_Tick);
            // 
            // timerThirdStock
            // 
            this.timerThirdStock.Interval = 60000;
            // 
            // timerFourthStock
            // 
            this.timerFourthStock.Interval = 60000;
            // 
            // StockDayForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.ClientSize = new System.Drawing.Size(1234, 838);
            this.Controls.Add(this.butSellStock);
            this.Controls.Add(this.butBuyStock);
            this.Controls.Add(this.butDel);
            this.Controls.Add(this.butAdd);
            this.Controls.Add(this.panelStockDayFourthEvent);
            this.Controls.Add(this.panelStockDayThirdEvent);
            this.Controls.Add(this.panelStockDaySecondEvent);
            this.Controls.Add(this.panelStockDayFirstEvent);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "StockDayForm";
            this.Text = "StockDayForm";
            this.Load += new System.EventHandler(this.StockDayForm_Load);
            this.panelStockDayFirstEvent.ResumeLayout(false);
            this.panelFirstStockBlank1.ResumeLayout(false);
            this.panelFirstStockBeforePrice.ResumeLayout(false);
            this.panelFirstStockCurPrice.ResumeLayout(false);
            this.panelStockDayFirstName.ResumeLayout(false);
            this.panelStockDaySecondEvent.ResumeLayout(false);
            this.panelSecondStockBeforePrice.ResumeLayout(false);
            this.panelSecondStockCurPrice.ResumeLayout(false);
            this.panelStockDayThirdEvent.ResumeLayout(false);
            this.panelStockDayFourthEvent.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelStockDayFirstEvent;
        private System.Windows.Forms.Timer timerFirstStock;
        private System.Windows.Forms.Panel panelStockDaySecondEvent;
        private System.Windows.Forms.Panel panelStockDayThirdEvent;
        private System.Windows.Forms.Panel panelStockDayFourthEvent;
        private System.Windows.Forms.Panel panelStockDayFirstName;
        private System.Windows.Forms.Label labFirstStockName;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.Button butDel;
        private System.Windows.Forms.Panel panelFirstStockBlank1;
        private System.Windows.Forms.Panel panelFirstStockBeforePrice;
        private System.Windows.Forms.Panel panelFirstStockCurPrice;
        private System.Windows.Forms.Label labFirstStockCurPriceName;
        private System.Windows.Forms.Label labFirstStockBeforePriceName;
        private System.Windows.Forms.Label labFirstStockCurFluctuation;
        private System.Windows.Forms.Label labFirstStockCurPrice;
        private System.Windows.Forms.Label labFirstStockCurFluctuationRate;
        private System.Windows.Forms.Label labFirstStockBuyPrice;
        private System.Windows.Forms.Label labFirstStockBuyPriceName;
        private System.Windows.Forms.Label labFirstStockBeforePrice;
        private System.Windows.Forms.Button butBuyStock;
        private System.Windows.Forms.Button butSellStock;
        private System.Windows.Forms.Timer timerSecondStock;
        private System.Windows.Forms.Timer timerThirdStock;
        private System.Windows.Forms.Timer timerFourthStock;
        private System.Windows.Forms.Label labFirstStockBenefitName;
        private System.Windows.Forms.Label labFirstStockBenefitFigure;
        private System.Windows.Forms.Label labSecondStockName;
        private System.Windows.Forms.Label labThirdStockName;
        private System.Windows.Forms.Label labFourthStockName;
        private System.Windows.Forms.Panel panelSecondStockBeforePrice;
        private System.Windows.Forms.Label labSecondStockBuyPrice;
        private System.Windows.Forms.Label labSecondStockBuyPriceName;
        private System.Windows.Forms.Label labSecondStockBeforePrice;
        private System.Windows.Forms.Label labSecondStockBeforePriceName;
        private System.Windows.Forms.Panel panelSecondStockCurPrice;
        private System.Windows.Forms.Label labSecondStockCurFluctuationRate;
        private System.Windows.Forms.Label labSecondStockCurFluctuation;
        private System.Windows.Forms.Label labSecondStockCurPrice;
        private System.Windows.Forms.Label labSecondStockCurPriceName;
        private System.Windows.Forms.Label labSecondStockBenefitFigure;
        private System.Windows.Forms.Label labSecondStockBenefitName;
    }
}