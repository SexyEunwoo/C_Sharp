﻿
namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_IP = new System.Windows.Forms.TextBox();
            this.but_Connect = new System.Windows.Forms.Button();
            this.text_Port = new System.Windows.Forms.TextBox();
            this.but_Disconnect = new System.Windows.Forms.Button();
            this.lab_ConnectionStatus = new System.Windows.Forms.Label();
            this.groupBox_Connection = new System.Windows.Forms.GroupBox();
            this.lab_Port = new System.Windows.Forms.Label();
            this.lab_IP = new System.Windows.Forms.Label();
            this.panel_Connection = new System.Windows.Forms.Panel();
            this.panel_Datas = new System.Windows.Forms.Panel();
            this.groupBox_Datas = new System.Windows.Forms.GroupBox();
            this.lab_RecvData = new System.Windows.Forms.Label();
            this.text_SendData = new System.Windows.Forms.TextBox();
            this.text_RcevData = new System.Windows.Forms.TextBox();
            this.lab_SendData = new System.Windows.Forms.Label();
            this.panel_ButtonData = new System.Windows.Forms.Panel();
            this.groupBox_ButtonData = new System.Windows.Forms.GroupBox();
            this.radio_HEX = new System.Windows.Forms.RadioButton();
            this.radio_DEC = new System.Windows.Forms.RadioButton();
            this.but_Send = new System.Windows.Forms.Button();
            this.lab_CurrentFunc = new System.Windows.Forms.Label();
            this.lab_StringCurrentFunc = new System.Windows.Forms.Label();
            this.lab_Data = new System.Windows.Forms.Label();
            this.text_Data = new System.Windows.Forms.TextBox();
            this.text_Length = new System.Windows.Forms.TextBox();
            this.lab_Length = new System.Windows.Forms.Label();
            this.lab_StartAddr = new System.Windows.Forms.Label();
            this.text_StartAddr = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.but_WriteCoil = new System.Windows.Forms.Button();
            this.but_WriteHreg = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.but_ReadCoil = new System.Windows.Forms.Button();
            this.but_ReadHreg = new System.Windows.Forms.Button();
            this.richText_Recv = new System.Windows.Forms.RichTextBox();
            this.lab_Logo = new System.Windows.Forms.Label();
            this.panel_Loop = new System.Windows.Forms.Panel();
            this.groupBox_Loop = new System.Windows.Forms.GroupBox();
            this.but_ClearRichText = new System.Windows.Forms.Button();
            this.lab_Interval = new System.Windows.Forms.Label();
            this.text_Interval = new System.Windows.Forms.TextBox();
            this.lab_LoopStatusDisplay = new System.Windows.Forms.Label();
            this.lab_LoopStatus = new System.Windows.Forms.Label();
            this.but_LoopStop = new System.Windows.Forms.Button();
            this.but_LoopStart = new System.Windows.Forms.Button();
            this.groupBox_History = new System.Windows.Forms.GroupBox();
            this.lab_CreatedBy = new System.Windows.Forms.Label();
            this.lab_CreateDate = new System.Windows.Forms.Label();
            this.but_Close = new System.Windows.Forms.Button();
            this.groupBox_Connection.SuspendLayout();
            this.panel_Connection.SuspendLayout();
            this.panel_Datas.SuspendLayout();
            this.groupBox_Datas.SuspendLayout();
            this.panel_ButtonData.SuspendLayout();
            this.groupBox_ButtonData.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel_Loop.SuspendLayout();
            this.groupBox_Loop.SuspendLayout();
            this.groupBox_History.SuspendLayout();
            this.SuspendLayout();
            // 
            // text_IP
            // 
            this.text_IP.Location = new System.Drawing.Point(78, 25);
            this.text_IP.Name = "text_IP";
            this.text_IP.Size = new System.Drawing.Size(118, 21);
            this.text_IP.TabIndex = 0;
            // 
            // but_Connect
            // 
            this.but_Connect.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.but_Connect.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_Connect.ForeColor = System.Drawing.Color.Black;
            this.but_Connect.Location = new System.Drawing.Point(202, 25);
            this.but_Connect.Name = "but_Connect";
            this.but_Connect.Size = new System.Drawing.Size(75, 23);
            this.but_Connect.TabIndex = 2;
            this.but_Connect.Text = "Connect";
            this.but_Connect.UseVisualStyleBackColor = true;
            this.but_Connect.Click += new System.EventHandler(this.but_Connect_Click);
            // 
            // text_Port
            // 
            this.text_Port.Location = new System.Drawing.Point(78, 65);
            this.text_Port.Name = "text_Port";
            this.text_Port.Size = new System.Drawing.Size(118, 21);
            this.text_Port.TabIndex = 1;
            // 
            // but_Disconnect
            // 
            this.but_Disconnect.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.but_Disconnect.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_Disconnect.ForeColor = System.Drawing.Color.Black;
            this.but_Disconnect.Location = new System.Drawing.Point(202, 63);
            this.but_Disconnect.Name = "but_Disconnect";
            this.but_Disconnect.Size = new System.Drawing.Size(75, 23);
            this.but_Disconnect.TabIndex = 3;
            this.but_Disconnect.Text = "Disconnect";
            this.but_Disconnect.UseVisualStyleBackColor = true;
            this.but_Disconnect.Click += new System.EventHandler(this.but_Disconnect_Click);
            // 
            // lab_ConnectionStatus
            // 
            this.lab_ConnectionStatus.AutoSize = true;
            this.lab_ConnectionStatus.Font = new System.Drawing.Font("Bahnschrift", 18.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ConnectionStatus.ForeColor = System.Drawing.Color.White;
            this.lab_ConnectionStatus.Location = new System.Drawing.Point(286, 41);
            this.lab_ConnectionStatus.Name = "lab_ConnectionStatus";
            this.lab_ConnectionStatus.Size = new System.Drawing.Size(161, 30);
            this.lab_ConnectionStatus.TabIndex = 4;
            this.lab_ConnectionStatus.Text = "Disconnected";
            this.lab_ConnectionStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox_Connection
            // 
            this.groupBox_Connection.Controls.Add(this.lab_Port);
            this.groupBox_Connection.Controls.Add(this.lab_IP);
            this.groupBox_Connection.Controls.Add(this.text_IP);
            this.groupBox_Connection.Controls.Add(this.but_Connect);
            this.groupBox_Connection.Controls.Add(this.text_Port);
            this.groupBox_Connection.Controls.Add(this.but_Disconnect);
            this.groupBox_Connection.Controls.Add(this.lab_ConnectionStatus);
            this.groupBox_Connection.Font = new System.Drawing.Font("돋움", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox_Connection.ForeColor = System.Drawing.Color.White;
            this.groupBox_Connection.Location = new System.Drawing.Point(8, 12);
            this.groupBox_Connection.Name = "groupBox_Connection";
            this.groupBox_Connection.Size = new System.Drawing.Size(450, 105);
            this.groupBox_Connection.TabIndex = 6;
            this.groupBox_Connection.TabStop = false;
            this.groupBox_Connection.Text = "Target";
            // 
            // lab_Port
            // 
            this.lab_Port.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Port.ForeColor = System.Drawing.Color.White;
            this.lab_Port.Location = new System.Drawing.Point(2, 63);
            this.lab_Port.Name = "lab_Port";
            this.lab_Port.Size = new System.Drawing.Size(76, 23);
            this.lab_Port.TabIndex = 6;
            this.lab_Port.Text = "Port";
            this.lab_Port.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_IP
            // 
            this.lab_IP.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_IP.ForeColor = System.Drawing.Color.White;
            this.lab_IP.Location = new System.Drawing.Point(3, 25);
            this.lab_IP.Name = "lab_IP";
            this.lab_IP.Size = new System.Drawing.Size(76, 23);
            this.lab_IP.TabIndex = 5;
            this.lab_IP.Text = "IP Addr";
            this.lab_IP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel_Connection
            // 
            this.panel_Connection.Controls.Add(this.groupBox_Connection);
            this.panel_Connection.Location = new System.Drawing.Point(0, 74);
            this.panel_Connection.Name = "panel_Connection";
            this.panel_Connection.Size = new System.Drawing.Size(470, 130);
            this.panel_Connection.TabIndex = 8;
            // 
            // panel_Datas
            // 
            this.panel_Datas.Controls.Add(this.groupBox_Datas);
            this.panel_Datas.Location = new System.Drawing.Point(0, 210);
            this.panel_Datas.Name = "panel_Datas";
            this.panel_Datas.Size = new System.Drawing.Size(470, 130);
            this.panel_Datas.TabIndex = 10;
            // 
            // groupBox_Datas
            // 
            this.groupBox_Datas.Controls.Add(this.lab_RecvData);
            this.groupBox_Datas.Controls.Add(this.text_SendData);
            this.groupBox_Datas.Controls.Add(this.text_RcevData);
            this.groupBox_Datas.Controls.Add(this.lab_SendData);
            this.groupBox_Datas.ForeColor = System.Drawing.Color.White;
            this.groupBox_Datas.Location = new System.Drawing.Point(8, 6);
            this.groupBox_Datas.Name = "groupBox_Datas";
            this.groupBox_Datas.Size = new System.Drawing.Size(450, 100);
            this.groupBox_Datas.TabIndex = 7;
            this.groupBox_Datas.TabStop = false;
            this.groupBox_Datas.Text = "Datas";
            // 
            // lab_RecvData
            // 
            this.lab_RecvData.AutoSize = true;
            this.lab_RecvData.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_RecvData.ForeColor = System.Drawing.Color.White;
            this.lab_RecvData.Location = new System.Drawing.Point(8, 63);
            this.lab_RecvData.Name = "lab_RecvData";
            this.lab_RecvData.Size = new System.Drawing.Size(66, 16);
            this.lab_RecvData.TabIndex = 12;
            this.lab_RecvData.Text = "받은 데이터";
            // 
            // text_SendData
            // 
            this.text_SendData.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.text_SendData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.text_SendData.Enabled = false;
            this.text_SendData.Location = new System.Drawing.Point(74, 22);
            this.text_SendData.Name = "text_SendData";
            this.text_SendData.Size = new System.Drawing.Size(358, 21);
            this.text_SendData.TabIndex = 0;
            // 
            // text_RcevData
            // 
            this.text_RcevData.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.text_RcevData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.text_RcevData.Enabled = false;
            this.text_RcevData.Location = new System.Drawing.Point(74, 60);
            this.text_RcevData.Name = "text_RcevData";
            this.text_RcevData.Size = new System.Drawing.Size(358, 21);
            this.text_RcevData.TabIndex = 11;
            // 
            // lab_SendData
            // 
            this.lab_SendData.AutoSize = true;
            this.lab_SendData.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_SendData.ForeColor = System.Drawing.Color.White;
            this.lab_SendData.Location = new System.Drawing.Point(8, 26);
            this.lab_SendData.Name = "lab_SendData";
            this.lab_SendData.Size = new System.Drawing.Size(66, 16);
            this.lab_SendData.TabIndex = 10;
            this.lab_SendData.Text = "보낸 데이터";
            // 
            // panel_ButtonData
            // 
            this.panel_ButtonData.Controls.Add(this.groupBox_ButtonData);
            this.panel_ButtonData.Location = new System.Drawing.Point(476, 74);
            this.panel_ButtonData.Name = "panel_ButtonData";
            this.panel_ButtonData.Size = new System.Drawing.Size(470, 130);
            this.panel_ButtonData.TabIndex = 11;
            // 
            // groupBox_ButtonData
            // 
            this.groupBox_ButtonData.Controls.Add(this.radio_HEX);
            this.groupBox_ButtonData.Controls.Add(this.radio_DEC);
            this.groupBox_ButtonData.Controls.Add(this.but_Send);
            this.groupBox_ButtonData.Controls.Add(this.lab_CurrentFunc);
            this.groupBox_ButtonData.Controls.Add(this.lab_StringCurrentFunc);
            this.groupBox_ButtonData.Controls.Add(this.lab_Data);
            this.groupBox_ButtonData.Controls.Add(this.text_Data);
            this.groupBox_ButtonData.Controls.Add(this.text_Length);
            this.groupBox_ButtonData.Controls.Add(this.lab_Length);
            this.groupBox_ButtonData.Controls.Add(this.lab_StartAddr);
            this.groupBox_ButtonData.Controls.Add(this.text_StartAddr);
            this.groupBox_ButtonData.Controls.Add(this.panel2);
            this.groupBox_ButtonData.ForeColor = System.Drawing.Color.White;
            this.groupBox_ButtonData.Location = new System.Drawing.Point(8, 12);
            this.groupBox_ButtonData.Name = "groupBox_ButtonData";
            this.groupBox_ButtonData.Padding = new System.Windows.Forms.Padding(8, 3, 3, 8);
            this.groupBox_ButtonData.Size = new System.Drawing.Size(450, 105);
            this.groupBox_ButtonData.TabIndex = 6;
            this.groupBox_ButtonData.TabStop = false;
            this.groupBox_ButtonData.Text = "Function";
            // 
            // radio_HEX
            // 
            this.radio_HEX.AutoSize = true;
            this.radio_HEX.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_HEX.Location = new System.Drawing.Point(395, 17);
            this.radio_HEX.Name = "radio_HEX";
            this.radio_HEX.Size = new System.Drawing.Size(47, 18);
            this.radio_HEX.TabIndex = 16;
            this.radio_HEX.TabStop = true;
            this.radio_HEX.Text = "HEX";
            this.radio_HEX.UseVisualStyleBackColor = true;
            this.radio_HEX.CheckedChanged += new System.EventHandler(this.radio_HEX_CheckedChanged);
            // 
            // radio_DEC
            // 
            this.radio_DEC.AutoSize = true;
            this.radio_DEC.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radio_DEC.Location = new System.Drawing.Point(347, 17);
            this.radio_DEC.Name = "radio_DEC";
            this.radio_DEC.Size = new System.Drawing.Size(47, 18);
            this.radio_DEC.TabIndex = 15;
            this.radio_DEC.TabStop = true;
            this.radio_DEC.Text = "DEC";
            this.radio_DEC.UseVisualStyleBackColor = true;
            this.radio_DEC.CheckedChanged += new System.EventHandler(this.radio_DEC_CheckedChanged);
            // 
            // but_Send
            // 
            this.but_Send.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_Send.Font = new System.Drawing.Font("Bahnschrift", 9F);
            this.but_Send.Location = new System.Drawing.Point(390, 46);
            this.but_Send.Name = "but_Send";
            this.but_Send.Size = new System.Drawing.Size(50, 50);
            this.but_Send.TabIndex = 14;
            this.but_Send.Text = "Send";
            this.but_Send.UseVisualStyleBackColor = true;
            this.but_Send.Click += new System.EventHandler(this.but_Send_Click);
            // 
            // lab_CurrentFunc
            // 
            this.lab_CurrentFunc.AutoSize = true;
            this.lab_CurrentFunc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CurrentFunc.Location = new System.Drawing.Point(266, 15);
            this.lab_CurrentFunc.Name = "lab_CurrentFunc";
            this.lab_CurrentFunc.Size = new System.Drawing.Size(51, 19);
            this.lab_CurrentFunc.TabIndex = 16;
            this.lab_CurrentFunc.Text = "NONE";
            // 
            // lab_StringCurrentFunc
            // 
            this.lab_StringCurrentFunc.AutoSize = true;
            this.lab_StringCurrentFunc.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_StringCurrentFunc.Location = new System.Drawing.Point(160, 15);
            this.lab_StringCurrentFunc.Name = "lab_StringCurrentFunc";
            this.lab_StringCurrentFunc.Size = new System.Drawing.Size(116, 19);
            this.lab_StringCurrentFunc.TabIndex = 15;
            this.lab_StringCurrentFunc.Text = "Currnet Func : ";
            // 
            // lab_Data
            // 
            this.lab_Data.AutoSize = true;
            this.lab_Data.Font = new System.Drawing.Font("Bahnschrift", 9F);
            this.lab_Data.Location = new System.Drawing.Point(178, 75);
            this.lab_Data.Name = "lab_Data";
            this.lab_Data.Size = new System.Drawing.Size(31, 14);
            this.lab_Data.TabIndex = 14;
            this.lab_Data.Text = "Data";
            // 
            // text_Data
            // 
            this.text_Data.Enabled = false;
            this.text_Data.Location = new System.Drawing.Point(222, 72);
            this.text_Data.Name = "text_Data";
            this.text_Data.Size = new System.Drawing.Size(155, 21);
            this.text_Data.TabIndex = 13;
            // 
            // text_Length
            // 
            this.text_Length.Location = new System.Drawing.Point(327, 43);
            this.text_Length.Name = "text_Length";
            this.text_Length.Size = new System.Drawing.Size(50, 21);
            this.text_Length.TabIndex = 12;
            // 
            // lab_Length
            // 
            this.lab_Length.AutoSize = true;
            this.lab_Length.Font = new System.Drawing.Font("Bahnschrift", 9F);
            this.lab_Length.Location = new System.Drawing.Point(279, 46);
            this.lab_Length.Name = "lab_Length";
            this.lab_Length.Size = new System.Drawing.Size(44, 14);
            this.lab_Length.TabIndex = 11;
            this.lab_Length.Text = "Length";
            // 
            // lab_StartAddr
            // 
            this.lab_StartAddr.AutoSize = true;
            this.lab_StartAddr.Font = new System.Drawing.Font("Bahnschrift", 9F);
            this.lab_StartAddr.Location = new System.Drawing.Point(164, 46);
            this.lab_StartAddr.Name = "lab_StartAddr";
            this.lab_StartAddr.Size = new System.Drawing.Size(58, 14);
            this.lab_StartAddr.TabIndex = 9;
            this.lab_StartAddr.Text = "StartAddr";
            // 
            // text_StartAddr
            // 
            this.text_StartAddr.Location = new System.Drawing.Point(222, 43);
            this.text_StartAddr.Name = "text_StartAddr";
            this.text_StartAddr.Size = new System.Drawing.Size(50, 21);
            this.text_StartAddr.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(8, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(151, 80);
            this.panel2.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.but_WriteCoil);
            this.panel3.Controls.Add(this.but_WriteHreg);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 40);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(151, 40);
            this.panel3.TabIndex = 8;
            // 
            // but_WriteCoil
            // 
            this.but_WriteCoil.Dock = System.Windows.Forms.DockStyle.Left;
            this.but_WriteCoil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_WriteCoil.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_WriteCoil.ForeColor = System.Drawing.Color.White;
            this.but_WriteCoil.Location = new System.Drawing.Point(75, 0);
            this.but_WriteCoil.Name = "but_WriteCoil";
            this.but_WriteCoil.Size = new System.Drawing.Size(75, 40);
            this.but_WriteCoil.TabIndex = 1;
            this.but_WriteCoil.Text = "WriteCoil";
            this.but_WriteCoil.UseVisualStyleBackColor = true;
            this.but_WriteCoil.Click += new System.EventHandler(this.but_WriteCoil_Click);
            // 
            // but_WriteHreg
            // 
            this.but_WriteHreg.Dock = System.Windows.Forms.DockStyle.Left;
            this.but_WriteHreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_WriteHreg.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_WriteHreg.ForeColor = System.Drawing.Color.White;
            this.but_WriteHreg.Location = new System.Drawing.Point(0, 0);
            this.but_WriteHreg.Name = "but_WriteHreg";
            this.but_WriteHreg.Size = new System.Drawing.Size(75, 40);
            this.but_WriteHreg.TabIndex = 3;
            this.but_WriteHreg.Text = "WriteHreg";
            this.but_WriteHreg.UseVisualStyleBackColor = true;
            this.but_WriteHreg.Click += new System.EventHandler(this.but_WriteHreg_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.but_ReadCoil);
            this.panel1.Controls.Add(this.but_ReadHreg);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(151, 40);
            this.panel1.TabIndex = 6;
            // 
            // but_ReadCoil
            // 
            this.but_ReadCoil.Dock = System.Windows.Forms.DockStyle.Left;
            this.but_ReadCoil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_ReadCoil.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_ReadCoil.ForeColor = System.Drawing.Color.White;
            this.but_ReadCoil.Location = new System.Drawing.Point(75, 0);
            this.but_ReadCoil.Name = "but_ReadCoil";
            this.but_ReadCoil.Size = new System.Drawing.Size(75, 40);
            this.but_ReadCoil.TabIndex = 1;
            this.but_ReadCoil.Text = "ReadCoil";
            this.but_ReadCoil.UseVisualStyleBackColor = true;
            this.but_ReadCoil.Click += new System.EventHandler(this.but_ReadCoil_Click);
            // 
            // but_ReadHreg
            // 
            this.but_ReadHreg.Dock = System.Windows.Forms.DockStyle.Left;
            this.but_ReadHreg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_ReadHreg.Font = new System.Drawing.Font("Bahnschrift", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_ReadHreg.ForeColor = System.Drawing.Color.White;
            this.but_ReadHreg.Location = new System.Drawing.Point(0, 0);
            this.but_ReadHreg.Name = "but_ReadHreg";
            this.but_ReadHreg.Size = new System.Drawing.Size(75, 40);
            this.but_ReadHreg.TabIndex = 3;
            this.but_ReadHreg.Text = "ReadHreg";
            this.but_ReadHreg.UseVisualStyleBackColor = true;
            this.but_ReadHreg.Click += new System.EventHandler(this.but_ReadHreg_Click);
            // 
            // richText_Recv
            // 
            this.richText_Recv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.richText_Recv.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richText_Recv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.richText_Recv.Font = new System.Drawing.Font("Bahnschrift SemiLight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richText_Recv.ForeColor = System.Drawing.Color.White;
            this.richText_Recv.Location = new System.Drawing.Point(3, 17);
            this.richText_Recv.Name = "richText_Recv";
            this.richText_Recv.ReadOnly = true;
            this.richText_Recv.Size = new System.Drawing.Size(934, 258);
            this.richText_Recv.TabIndex = 12;
            this.richText_Recv.Text = "";
            // 
            // lab_Logo
            // 
            this.lab_Logo.AutoSize = true;
            this.lab_Logo.Font = new System.Drawing.Font("Bahnschrift", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Logo.ForeColor = System.Drawing.Color.White;
            this.lab_Logo.Location = new System.Drawing.Point(238, 19);
            this.lab_Logo.Name = "lab_Logo";
            this.lab_Logo.Size = new System.Drawing.Size(455, 39);
            this.lab_Logo.TabIndex = 13;
            this.lab_Logo.Text = "Modbus_TCP/IP Communicator";
            // 
            // panel_Loop
            // 
            this.panel_Loop.Controls.Add(this.groupBox_Loop);
            this.panel_Loop.Location = new System.Drawing.Point(476, 210);
            this.panel_Loop.Name = "panel_Loop";
            this.panel_Loop.Size = new System.Drawing.Size(470, 130);
            this.panel_Loop.TabIndex = 14;
            // 
            // groupBox_Loop
            // 
            this.groupBox_Loop.Controls.Add(this.but_ClearRichText);
            this.groupBox_Loop.Controls.Add(this.lab_Interval);
            this.groupBox_Loop.Controls.Add(this.text_Interval);
            this.groupBox_Loop.Controls.Add(this.lab_LoopStatusDisplay);
            this.groupBox_Loop.Controls.Add(this.lab_LoopStatus);
            this.groupBox_Loop.Controls.Add(this.but_LoopStop);
            this.groupBox_Loop.Controls.Add(this.but_LoopStart);
            this.groupBox_Loop.ForeColor = System.Drawing.Color.White;
            this.groupBox_Loop.Location = new System.Drawing.Point(8, 6);
            this.groupBox_Loop.Name = "groupBox_Loop";
            this.groupBox_Loop.Size = new System.Drawing.Size(450, 100);
            this.groupBox_Loop.TabIndex = 7;
            this.groupBox_Loop.TabStop = false;
            this.groupBox_Loop.Text = "Loop";
            // 
            // but_ClearRichText
            // 
            this.but_ClearRichText.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_ClearRichText.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_ClearRichText.ForeColor = System.Drawing.Color.White;
            this.but_ClearRichText.Location = new System.Drawing.Point(324, 19);
            this.but_ClearRichText.Name = "but_ClearRichText";
            this.but_ClearRichText.Size = new System.Drawing.Size(116, 70);
            this.but_ClearRichText.TabIndex = 21;
            this.but_ClearRichText.Text = "Clear History";
            this.but_ClearRichText.UseVisualStyleBackColor = true;
            this.but_ClearRichText.Click += new System.EventHandler(this.but_ClearRichText_Click);
            // 
            // lab_Interval
            // 
            this.lab_Interval.AutoSize = true;
            this.lab_Interval.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Interval.ForeColor = System.Drawing.Color.White;
            this.lab_Interval.Location = new System.Drawing.Point(228, 65);
            this.lab_Interval.Name = "lab_Interval";
            this.lab_Interval.Size = new System.Drawing.Size(80, 16);
            this.lab_Interval.TabIndex = 20;
            this.lab_Interval.Text = "ms(Interval)";
            this.lab_Interval.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // text_Interval
            // 
            this.text_Interval.Location = new System.Drawing.Point(175, 63);
            this.text_Interval.Name = "text_Interval";
            this.text_Interval.Size = new System.Drawing.Size(51, 21);
            this.text_Interval.TabIndex = 19;
            // 
            // lab_LoopStatusDisplay
            // 
            this.lab_LoopStatusDisplay.AutoSize = true;
            this.lab_LoopStatusDisplay.Font = new System.Drawing.Font("Bahnschrift", 18.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_LoopStatusDisplay.ForeColor = System.Drawing.Color.White;
            this.lab_LoopStatusDisplay.Location = new System.Drawing.Point(254, 19);
            this.lab_LoopStatusDisplay.Name = "lab_LoopStatusDisplay";
            this.lab_LoopStatusDisplay.Size = new System.Drawing.Size(72, 30);
            this.lab_LoopStatusDisplay.TabIndex = 18;
            this.lab_LoopStatusDisplay.Text = "STOP";
            this.lab_LoopStatusDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lab_LoopStatus
            // 
            this.lab_LoopStatus.AutoSize = true;
            this.lab_LoopStatus.Font = new System.Drawing.Font("Bahnschrift", 18.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_LoopStatus.ForeColor = System.Drawing.Color.White;
            this.lab_LoopStatus.Location = new System.Drawing.Point(164, 19);
            this.lab_LoopStatus.Name = "lab_LoopStatus";
            this.lab_LoopStatus.Size = new System.Drawing.Size(104, 30);
            this.lab_LoopStatus.TabIndex = 17;
            this.lab_LoopStatus.Text = "Status : ";
            this.lab_LoopStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // but_LoopStop
            // 
            this.but_LoopStop.Enabled = false;
            this.but_LoopStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_LoopStop.Font = new System.Drawing.Font("Bahnschrift", 9F);
            this.but_LoopStop.ForeColor = System.Drawing.Color.White;
            this.but_LoopStop.Location = new System.Drawing.Point(88, 20);
            this.but_LoopStop.Name = "but_LoopStop";
            this.but_LoopStop.Size = new System.Drawing.Size(70, 70);
            this.but_LoopStop.TabIndex = 16;
            this.but_LoopStop.Text = "Stop";
            this.but_LoopStop.UseVisualStyleBackColor = true;
            this.but_LoopStop.Click += new System.EventHandler(this.but_LoopStop_Click);
            // 
            // but_LoopStart
            // 
            this.but_LoopStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_LoopStart.Font = new System.Drawing.Font("Bahnschrift", 9F);
            this.but_LoopStart.ForeColor = System.Drawing.Color.White;
            this.but_LoopStart.Location = new System.Drawing.Point(10, 20);
            this.but_LoopStart.Name = "but_LoopStart";
            this.but_LoopStart.Size = new System.Drawing.Size(70, 70);
            this.but_LoopStart.TabIndex = 15;
            this.but_LoopStart.Text = "Start";
            this.but_LoopStart.UseVisualStyleBackColor = true;
            this.but_LoopStart.Click += new System.EventHandler(this.but_LoopStart_Click);
            // 
            // groupBox_History
            // 
            this.groupBox_History.Controls.Add(this.richText_Recv);
            this.groupBox_History.ForeColor = System.Drawing.Color.White;
            this.groupBox_History.Location = new System.Drawing.Point(3, 346);
            this.groupBox_History.Name = "groupBox_History";
            this.groupBox_History.Size = new System.Drawing.Size(940, 278);
            this.groupBox_History.TabIndex = 13;
            this.groupBox_History.TabStop = false;
            this.groupBox_History.Text = "History";
            // 
            // lab_CreatedBy
            // 
            this.lab_CreatedBy.AutoSize = true;
            this.lab_CreatedBy.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CreatedBy.ForeColor = System.Drawing.Color.White;
            this.lab_CreatedBy.Location = new System.Drawing.Point(787, 39);
            this.lab_CreatedBy.Name = "lab_CreatedBy";
            this.lab_CreatedBy.Size = new System.Drawing.Size(116, 19);
            this.lab_CreatedBy.TabIndex = 15;
            this.lab_CreatedBy.Text = "Created by EW";
            // 
            // lab_CreateDate
            // 
            this.lab_CreateDate.AutoSize = true;
            this.lab_CreateDate.Font = new System.Drawing.Font("Bahnschrift SemiBold", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_CreateDate.ForeColor = System.Drawing.Color.White;
            this.lab_CreateDate.Location = new System.Drawing.Point(787, 19);
            this.lab_CreateDate.Name = "lab_CreateDate";
            this.lab_CreateDate.Size = new System.Drawing.Size(116, 19);
            this.lab_CreateDate.TabIndex = 16;
            this.lab_CreateDate.Text = "2021-01-20 v1.0";
            // 
            // but_Close
            // 
            this.but_Close.BackColor = System.Drawing.Color.Gray;
            this.but_Close.FlatAppearance.BorderSize = 0;
            this.but_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.but_Close.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_Close.ForeColor = System.Drawing.Color.White;
            this.but_Close.Location = new System.Drawing.Point(921, 0);
            this.but_Close.Name = "but_Close";
            this.but_Close.Size = new System.Drawing.Size(25, 25);
            this.but_Close.TabIndex = 17;
            this.but_Close.Text = "X";
            this.but_Close.UseVisualStyleBackColor = false;
            this.but_Close.Click += new System.EventHandler(this.but_Close_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.ClientSize = new System.Drawing.Size(946, 627);
            this.Controls.Add(this.but_Close);
            this.Controls.Add(this.lab_CreateDate);
            this.Controls.Add(this.lab_CreatedBy);
            this.Controls.Add(this.groupBox_History);
            this.Controls.Add(this.panel_Loop);
            this.Controls.Add(this.lab_Logo);
            this.Controls.Add(this.panel_ButtonData);
            this.Controls.Add(this.panel_Datas);
            this.Controls.Add(this.panel_Connection);
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.groupBox_Connection.ResumeLayout(false);
            this.groupBox_Connection.PerformLayout();
            this.panel_Connection.ResumeLayout(false);
            this.panel_Datas.ResumeLayout(false);
            this.groupBox_Datas.ResumeLayout(false);
            this.groupBox_Datas.PerformLayout();
            this.panel_ButtonData.ResumeLayout(false);
            this.groupBox_ButtonData.ResumeLayout(false);
            this.groupBox_ButtonData.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel_Loop.ResumeLayout(false);
            this.groupBox_Loop.ResumeLayout(false);
            this.groupBox_Loop.PerformLayout();
            this.groupBox_History.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox text_IP;
        private System.Windows.Forms.Button but_Connect;
        private System.Windows.Forms.TextBox text_Port;
        private System.Windows.Forms.Button but_Disconnect;
        private System.Windows.Forms.Label lab_ConnectionStatus;
        private System.Windows.Forms.GroupBox groupBox_Connection;
        private System.Windows.Forms.Label lab_Port;
        private System.Windows.Forms.Label lab_IP;
        private System.Windows.Forms.Panel panel_Connection;
        private System.Windows.Forms.Panel panel_Datas;
        private System.Windows.Forms.Label lab_RecvData;
        private System.Windows.Forms.TextBox text_RcevData;
        private System.Windows.Forms.Label lab_SendData;
        private System.Windows.Forms.TextBox text_SendData;
        private System.Windows.Forms.Panel panel_ButtonData;
        private System.Windows.Forms.GroupBox groupBox_ButtonData;
        private System.Windows.Forms.Button but_ReadCoil;
        private System.Windows.Forms.Button but_ReadHreg;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lab_StartAddr;
        private System.Windows.Forms.TextBox text_StartAddr;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button but_WriteCoil;
        private System.Windows.Forms.Button but_WriteHreg;
        private System.Windows.Forms.Label lab_Length;
        private System.Windows.Forms.TextBox text_Length;
        private System.Windows.Forms.Label lab_Data;
        private System.Windows.Forms.TextBox text_Data;
        private System.Windows.Forms.Label lab_CurrentFunc;
        private System.Windows.Forms.Label lab_StringCurrentFunc;
        private System.Windows.Forms.GroupBox groupBox_Datas;
        private System.Windows.Forms.Button but_Send;
        private System.Windows.Forms.RadioButton radio_HEX;
        private System.Windows.Forms.RadioButton radio_DEC;
        private System.Windows.Forms.Label lab_Logo;
        private System.Windows.Forms.Panel panel_Loop;
        private System.Windows.Forms.GroupBox groupBox_Loop;
        private System.Windows.Forms.Button but_LoopStart;
        private System.Windows.Forms.Label lab_Interval;
        private System.Windows.Forms.TextBox text_Interval;
        private System.Windows.Forms.Label lab_LoopStatusDisplay;
        private System.Windows.Forms.Label lab_LoopStatus;
        private System.Windows.Forms.Button but_LoopStop;
        private System.Windows.Forms.GroupBox groupBox_History;
        public System.Windows.Forms.RichTextBox richText_Recv;
        private System.Windows.Forms.Button but_ClearRichText;
        private System.Windows.Forms.Label lab_CreatedBy;
        private System.Windows.Forms.Label lab_CreateDate;
        private System.Windows.Forms.Button but_Close;
    }
}

