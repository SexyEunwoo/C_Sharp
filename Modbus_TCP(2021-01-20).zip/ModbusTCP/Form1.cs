﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private const int LOOP_MIN_MILLIS = 100;
        private struct MBAP
        {
            public short tid;
            public short pid;
            public short length;
            public byte uid;
        };
        private enum FUNCTION_CODE
        {
            NONE,
            READ_COILES,
            READ_DISCRETE_INPUTS,
            READ_MULTI_HREG,
            READ_INPUT_REG,
            WRITE_SINGLE_COIL,
            WRITE_SINGLE_HREG,
            WRITE_MULTIPLE_COILS = 15,
            WRITE_MULTI_HREGS = 16
        };

        private short startAddr;
        private short length;
        private byte byteCount;

        private byte[] send_data;
        private byte[] read_data;
        private Socket sock;
        private bool isConnected;
        private string ip;
        private int port;

        private MBAP mbap;
        private byte funcCode;

        private System.Threading.Timer sock_timer;
        private System.Threading.Timer send_loop_timer;
        private Point mousePoint;

        private ModbusTCP_Parser parser;
        private bool isParserOn;
        private int millis;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sock_timer = new System.Threading.Timer(sock_Timer_Callback, null, 0, 40);

            mbap = new MBAP();
            mbap.tid = 0x00;
            mbap.pid = 0x00;
            mbap.uid = 0x01;

            send_data = new byte[255];
            read_data = new byte[255];
            funcCode = 0x00;
            groupBox_ButtonData.Enabled = false;
            groupBox_Datas.Enabled = false;
            groupBox_Loop.Enabled = false;
            but_LoopStop.BackColor = Color.FromArgb(90, 90, 90);

            radio_DEC.Checked = true;
            isParserOn = false;
            parser = new ModbusTCP_Parser();

        }

        private void but_Connect_Click(object sender, EventArgs e)
        {
            if(text_IP.Text == "" || text_Port.Text == "")
            {
                MessageBox.Show("IP주소와 PORT번호를 적으십시오", "ERROR");
                return;
            }

            if(isConnected)
            {
                string err = string.Format("이미 연결되어 있습니다 {0}", ip);
                MessageBox.Show(err, "ERROR");
                return;
            }
            ip = get_Text_IP();  //text_IP.Text;
            port = Convert.ToInt32(text_Port.Text);

            try
            {
                connect_To_Server();
            }
            catch(Exception ex)
            {
                string err = string.Format("Error : {0}, Please Check your IP address or Port number", ex.Message);
                MessageBox.Show(err, "Error");
                return;
            }

            lab_ConnectionStatus.Text = "Connected";

            groupBox_ButtonData.Enabled = true;
            groupBox_Datas.Enabled = true;
            groupBox_Loop.Enabled = true;
        }

        private void but_Disconnect_Click(object sender, EventArgs e)
        {
                if (sock != null && sock.Connected)
                {
                    sock.Dispose();
                    lab_ConnectionStatus.Text = "Disconnected";
                    isConnected = false;

                    groupBox_ButtonData.Enabled = false;
                    groupBox_Datas.Enabled = false;
                    groupBox_Loop.Enabled = false;
                }
                else
                {
                    MessageBox.Show("You're not connected");
                }
        }

        private void but_ReadHreg_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.READ_MULTI_HREG;
            text_Data.Enabled = false;
            set_Cur_Func();
        }

        private void but_ReadCoil_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.READ_COILES;
            text_Data.Enabled = false;
            set_Cur_Func();
        }

        private void but_WriteHreg_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.WRITE_MULTI_HREGS;
            text_Data.Enabled = true;
            set_Cur_Func();
        }

        private void but_WriteCoil_Click(object sender, EventArgs e)
        {
            funcCode = (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS;
            text_Data.Enabled = true;
            set_Cur_Func();
        }

        private void set_Cur_Func()
        {
            switch(funcCode)
            {
                case (byte)FUNCTION_CODE.READ_COILES:
                case (byte)FUNCTION_CODE.READ_DISCRETE_INPUTS:
                    lab_CurrentFunc.Text = "ReadCoil";
                    break;
                case (byte)FUNCTION_CODE.READ_MULTI_HREG:
                case (byte)FUNCTION_CODE.READ_INPUT_REG:
                    lab_CurrentFunc.Text = "ReadHreg";
                    break;
                case (byte)FUNCTION_CODE.WRITE_SINGLE_COIL:
                case (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS:
                    lab_CurrentFunc.Text = "WriteCoil";
                    break;
                case (byte)FUNCTION_CODE.WRITE_SINGLE_HREG:
                case (byte)FUNCTION_CODE.WRITE_MULTI_HREGS:
                    lab_CurrentFunc.Text = "WriteHreg";
                    break;
                case (byte)FUNCTION_CODE.NONE:
                    lab_CurrentFunc.Text = "NONE";
                    break;
            }
        }

        private void but_Send_Click(object sender, EventArgs e)
        {
            if(funcCode == (byte)FUNCTION_CODE.NONE)
            {
                MessageBox.Show("동작방식을 선택하십시오", "Error");
                return;
            }

            if(text_StartAddr.Text == "" || text_Length.Text == "")
            {
                MessageBox.Show("시작주소 또는 길이가 누락되었습니다.", "Error");
                return;
            }

            send();
        }

        private void send()
        {
            text_RcevData.Text = "";
            text_SendData.Text = "";
            string[] str_data;
            int size = 0;

            size = 7; // MBAP Length

            switch (funcCode)
            {
                case (byte)FUNCTION_CODE.READ_COILES:
                case (byte)FUNCTION_CODE.READ_DISCRETE_INPUTS:
                case (byte)FUNCTION_CODE.READ_MULTI_HREG:
                case (byte)FUNCTION_CODE.READ_INPUT_REG:

                    startAddr = (short)get_Text_StartAddr();
                    if (startAddr == Int16.MaxValue)
                        return;

                    length = (short)get_Text_Length();
                    if (length == Int16.MaxValue)
                        return;

                    mbap.length = 0x06;
                    send_data[0] = (byte)(mbap.tid >> 8);
                    send_data[1] = (byte)mbap.tid;
                    send_data[2] = (byte)(mbap.pid >> 8);
                    send_data[3] = (byte)mbap.pid;
                    send_data[4] = (byte)(mbap.length >> 8);
                    send_data[5] = (byte)mbap.length;
                    send_data[6] = mbap.uid;

                    send_data[size] = funcCode;
                    size += sizeof(byte);       // FuncCode Length

                    send_data[size] = (byte)(startAddr >> 8);
                    send_data[size+1] = (byte)startAddr;
                    size += sizeof(short);    // Start Address Length

                    send_data[size] = (byte)(length >> 8);
                    send_data[size+1] = (byte)length;
                    size += sizeof(short); // Read Length

                    break;

                case (byte)FUNCTION_CODE.WRITE_SINGLE_HREG:
                case (byte)FUNCTION_CODE.WRITE_MULTI_HREGS:

                    startAddr = (short)get_Text_StartAddr();  // returns string to dec or hex 
                    if (startAddr == Int16.MaxValue)
                        return;

                    length = (short)get_Text_Length(); // returns string to dec or hex 
                    if (length == Int16.MaxValue || length > 127)
                        return;

                    byteCount = (byte)(length * 2);

                    str_data = get_Text_Data_Strings();
                    if(str_data.Length < length)
                    {
                        string str = string.Format("Error : Require {0}data, Read {1}data", length, str_data.Length);
                        MessageBox.Show(str);
                        return;
                    }

                    mbap.length = 0x07; // Unit ID, StartAddr, Length, DataByteLength
                    mbap.length += byteCount;
                    send_data[0] = (byte)(mbap.tid >> 8);
                    send_data[1] = (byte)mbap.tid;
                    send_data[2] = (byte)(mbap.pid >> 8);
                    send_data[3] = (byte)mbap.pid;
                    send_data[4] = (byte)(mbap.length >> 8);
                    send_data[5] = (byte)mbap.length;
                    send_data[6] = mbap.uid;

                    send_data[size++] = funcCode;

                    send_data[size++] = (byte)(startAddr >> 8);
                    send_data[size++] = (byte)(startAddr);

                    send_data[size++] = (byte)(length >> 8);
                    send_data[size++] = (byte)length;

                    send_data[size++] = byteCount;

                    for (int i = 0; i < str_data.Length; i++)
                    {
                        short temp = string_To_Number(str_data[i]);
                        send_data[size++] = (byte)(temp >> 8);
                        send_data[size++] = (byte)temp;
                    }
                    break;

                case (byte)FUNCTION_CODE.WRITE_SINGLE_COIL:
                case (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS:

                    startAddr = (short)get_Text_StartAddr();  // returns string to dec or hex 
                    if (startAddr == Int16.MaxValue)
                        return;

                    length = (short)get_Text_Length(); // returns string to dec or hex 
                    if (length == Int16.MaxValue || length > 127)
                        return;

                    if (length <= 8)
                        byteCount = 1;
                    else
                        byteCount = (byte)((length / 9) + 1);

                    // byte tempData = (byte)(string_To_Number(text_Data.Text) >> 8);

                    str_data = text_Data.Text.Split(' ');
                    if (str_data.Length != byteCount)
                    {
                        string str = string.Format("Error : Require {0}data, Read {1}data", byteCount, str_data.Length);
                        MessageBox.Show(str);
                        return;
                    }


                    mbap.length = 0x07; // Unit ID, StartAddr, Length, DataByteLength
                    mbap.length += byteCount;
                    send_data[0] = (byte)(mbap.tid >> 8);
                    send_data[1] = (byte)mbap.tid;
                    send_data[2] = (byte)(mbap.pid >> 8);
                    send_data[3] = (byte)mbap.pid;
                    send_data[4] = (byte)(mbap.length >> 8);
                    send_data[5] = (byte)mbap.length;
                    send_data[6] = mbap.uid;

                    send_data[size++] = funcCode;

                    send_data[size++] = (byte)(startAddr >> 8);
                    send_data[size++] = (byte)(startAddr);

                    send_data[size++] = (byte)(length >> 8);
                    send_data[size++] = (byte)length;

                    send_data[size++] = byteCount;

                    for (int i = 0; i < str_data.Length; i++)
                    {
                        short temp = string_To_Number(str_data[i]);
                        send_data[size++] = (byte)temp;
                    }

                    break;
            }

            for(int i = 0; i < size; i++)
            {
                text_SendData.Text += send_data[i].ToString("X2") + " ";
            }

            try
            {
                sock.Send(send_data, size, SocketFlags.None);
            }
            catch(Exception excep)
            {
                lab_ConnectionStatus.Text = "Disconnected";
                lab_LoopStatusDisplay.Text = "STOP";
                send_loop_timer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
                MessageBox.Show("Disconnected with Server...");
                DialogResult ret = MessageBox.Show("Do you want to Reconnect?", "Reconnect", MessageBoxButtons.YesNo);

                switch(ret)
                {
                    case DialogResult.Yes:
                        if (connect_To_Server())
                        {
                            send_loop_timer.Change(0, millis);
                            lab_ConnectionStatus.Text = "Connected";
                            lab_LoopStatusDisplay.Text = "LOOP";
                        }
                        break;
                }
            }

        }

        private void sock_Timer_Callback(object state)
        {
            if(sock == null || !sock.Connected)
            {
                return;
            }
            Invoke(new MethodInvoker(
                    delegate ()
                    {
                        if(sock.Available > 0)
                        {
                            int len = sock.Available;
                           sock.Receive(read_data, len, SocketFlags.None);

                            for(int i = 0; i < len; i++)
                            {
                                if (sock.Available > 0)
                                    len += sock.Receive(read_data, len, SocketFlags.None);

                                text_RcevData.AppendText(read_data[i].ToString("X2") + " ");
                            }
                            string str = string.Format("{0} >> ", DateTime.Now.ToString("HH:mm:ss"));
                            richText_Recv.Text += str;
                            for(int i = 0; i < len; i++)
                            {
                                richText_Recv.AppendText(read_data[i].ToString("X2") + " ");
                            }
                            richText_Recv.AppendText("\n");

                            if (true) // isParseOn
                            {
                                parser.modbus_Parse(read_data, this);
                            }

                            richText_Recv.ScrollToCaret();
                        }
                    }));
        }

        private short string_To_Number(string str)
        {
            try
            {
                if (radio_HEX.Checked)
                {
                    return Convert.ToInt16(str, 16);
                }
                else
                {
                    return Convert.ToInt16(str, 10);
                }
            }
            catch(Exception excep)
            {
                string err = string.Format("Error : {0}", excep.Message);
                MessageBox.Show(err, "Error");
            }

            return Int16.MaxValue;
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mousePoint = new Point(e.X, e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Left)
            {
                int x = mousePoint.X - e.X;
                int y = mousePoint.Y - e.Y;
                Location = new Point(this.Left - x, this.Top - y);
            }
        }

        private void but_LoopStart_Click(object sender, EventArgs e)
        {
            if(text_Interval.Text == "")
            {
                MessageBox.Show("Interval bos is empty", "Erorr");
                return;
            }

            millis = Convert.ToInt32(text_Interval.Text);
            if (millis < LOOP_MIN_MILLIS)
            {
                MessageBox.Show("Min loop interval is 100ms", "Error");
                return;
            }

            if (funcCode == (byte)FUNCTION_CODE.NONE)
            {
                MessageBox.Show("동작방식을 선택하십시오", "Error");
                return;
            }

            if (text_StartAddr.Text == "" || text_Length.Text == "")
            {
                MessageBox.Show("시작주소 또는 길이가 누락되었습니다.", "Error");
                return;
            }

            if (text_Data.Enabled)
            {
                if (text_Data.Text == "")
                {
                    MessageBox.Show("데이터가 누락되었습니다.", "Error");
                    return;
                }
                else
                {
                    string str;
                    string[] strs;
                    if (text_Data.Text.EndsWith(" "))
                        str = text_Data.Text.Substring(0, text_Data.Text.Length - 1);
                    else
                        str = text_Data.Text;

                    strs = str.Split(' ');
                    int required_length = get_Text_Length();
                    if (required_length != strs.Length)
                    {
                        str = string.Format("Error : Require {0}data, Read {1}data", required_length, strs.Length);
                        MessageBox.Show(str, "Error");
                        return;
                    }
                }
            }
            send_loop_timer = new System.Threading.Timer(loop_Callback, 0, 0, millis);


            but_LoopStart.BackColor = Color.FromArgb(90, 90, 90);
            but_LoopStart.Enabled = false;

            but_LoopStop.BackColor = Color.FromArgb(50, 50, 50);
            but_LoopStop.Enabled = true;

            lab_LoopStatusDisplay.Text = "LOOP";
        }

        private void loop_Callback(object state)
        {
            if (this.InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate ()
                {
                    but_Send_Click(null, null);
                }));
            }
        }

        private void but_LoopStop_Click(object sender, EventArgs e)
        {
            if(send_loop_timer != null)
            {
                send_loop_timer.Dispose();
            }

            but_LoopStop.BackColor = Color.FromArgb(90, 90, 90);
            but_LoopStop.Enabled = false;

            but_LoopStart.BackColor = Color.FromArgb(50, 50, 50);
            but_LoopStart.Enabled = true;

            lab_LoopStatusDisplay.Text = "STOP";
        }

        private void but_ClearRichText_Click(object sender, EventArgs e)
        {
            richText_Recv.Text = "";
        }

        private void radio_HEX_CheckedChanged(object sender, EventArgs e)
        {
            if (radio_HEX.Checked)
            {
                try
                {
                    if (text_StartAddr.Text != "")
                    {
                        int startAddr = get_Text_StartAddr(true);
                        text_StartAddr.Text = string.Format("{0:X2}", startAddr);
                    }
                }
                catch { }

                try
                {
                    if (text_Length.Text != "")
                    {
                        int length = get_Text_Length(true);
                        text_Length.Text = string.Format("{0:X2}", length);
                    }
                }
                catch { }

                try
                {
                    string[] datas;
                    string output = "";
                    if (text_Data.Text.EndsWith(" "))
                    {
                        datas = text_Data.Text.Substring(0, text_Data.Text.Length - 1).Split(' ');
                    }
                    else
                    {
                        datas = text_Data.Text.Split(' ');
                    }

                    foreach (string str in datas)
                    {
                        int length = Convert.ToInt32(str);
                        output += string.Format("{0} ", string.Format("{0:X2}", length));
                    }
                    text_Data.Text = output;
                }
                catch { }
            }
        }

        private void radio_DEC_CheckedChanged(object sender, EventArgs e)
        {
            if (radio_DEC.Checked)
            {
                try
                {
                    if (text_StartAddr.Text != "")
                    {
                        int startAddr = get_Text_StartAddr(true);
                        text_StartAddr.Text = string.Format("{0}", startAddr);
                    }
                }
                catch { }

                try
                {
                    if (text_Length.Text != "")
                    {
                        int length = get_Text_Length(true);
                        text_Length.Text = string.Format("{0}", length);
                    }
                }
                catch { }

                try
                {
                    string[] datas;
                    string output = "";
                    if(text_Data.Text.EndsWith(" "))
                    {
                        datas = text_Data.Text.Substring(0, text_Data.Text.Length - 1).Split(' ');
                    }
                    else
                    {
                        datas = text_Data.Text.Split(' ');
                    }

                    foreach (string str in datas)
                    {
                        int length = Convert.ToInt32(str, 16);
                        output += string.Format("{0} ", string.Format("{0}", length));
                    }
                    text_Data.Text = output;
                }
                catch { }
            }
        }

        private string get_Text_IP()
        {
            if (text_IP.Text == "")
            {
                MessageBox.Show("IP 또는 Domain 주소를 적으십시오", "Error");
                return null;
            }

            string str = text_IP.Text;
            try
            {
                IPHostEntry ipHostEntry = Dns.GetHostByName(str);
                str = ipHostEntry.AddressList[0].ToString();
                return str;
            }
            catch
            {
                return str;
            }
        }

        private int get_Text_Length(bool radio = false)
        {
            if (radio)
            {
                if (radio_HEX.Checked)
                    return Convert.ToInt32(text_Length.Text);
                else
                    return Convert.ToInt32(text_Length.Text, 16);
            }
            else
            {
                if (radio_DEC.Checked)
                    return Convert.ToInt32(text_Length.Text);
                else
                    return Convert.ToInt32(text_Length.Text, 16);
            }
        }

        private int get_Text_StartAddr(bool radio = false)
        {
            if (radio)
            {
                if (radio_HEX.Checked)
                    return Convert.ToInt32(text_StartAddr.Text);
                else
                    return Convert.ToInt32(text_StartAddr.Text, 16);
            }
            else
            {
                if (radio_DEC.Checked)
                    return Convert.ToInt32(text_StartAddr.Text);
                else
                    return Convert.ToInt32(text_StartAddr.Text, 16);
            }
        }

        private string[] get_Text_Data_Strings()
        {
            string str;

            if (text_Data.Text.EndsWith(" "))
                str = text_Data.Text.Substring(0, text_Data.Text.Length - 1);
            else
                str = text_Data.Text;

            return str.Split(' ');
        }

        private void but_Close_Click(object sender, EventArgs e)
        {
            DialogResult ret = MessageBox.Show("Are you sure to close?", "Close", MessageBoxButtons.OKCancel);

            switch(ret)
            {
                case DialogResult.OK:
                    /*
                     * 1. timer thread 중지
                     * 2. 0.5초 대기( timer thread가 종료되는 시간 )
                     * 3. socket shut-down(half-close)
                     * 4. 0.5초 대기(혹시 전송되는 데이터가 있을 경우를 위함)
                     */
                    if (sock != null)
                    {
                        if(send_loop_timer != null)
                            send_loop_timer.Dispose();
                        if(sock_timer != null)
                            sock_timer.Dispose();
                        Thread.Sleep(500);
                        
                        if(sock.Connected)
                            sock.Shutdown(SocketShutdown.Send);
                        Thread.Sleep(500);
                    }

                    this.Close();
                    break;
            }
        }
        
        private bool connect_To_Server()
        {
            sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IAsyncResult result = sock.BeginConnect(ip, port, null, null);

            bool success = result.AsyncWaitHandle.WaitOne(2000, true);

            if (sock.Connected)
            {
                sock.EndConnect(result);
                isConnected = true;
                return true;
            }
            else
            {
                throw new ApplicationException("Failed to connect server.");
            }
        }
    }
}
