﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class ModbusTCP_Parser
    {
        readonly int MAX_DATA = 255;
        readonly string[] strs = new string[] {
            "TID ------->",
            "PID ------->",
            "LID ------->",
            "UID ------->",
            "FuncCode ->",
            "ByteCount ->",
            "StartAddr   ->",
            "Length ------>",
        };
        private enum FUNCTION_CODE
        {
            NONE,
            READ_COILES,
            READ_DISCRETE_INPUTS,
            READ_MULTI_HREG,
            READ_INPUT_REG,
            WRITE_SINGLE_COIL,
            WRITE_SINGLE_HREG,
            WRITE_MULTIPLE_COILS = 15,
            WRITE_MULTI_HREGS = 16
        };
        private struct MBAP
        {
            public short tid;
            public short pid;
            public short length;
            public byte uid;
        };
        private enum OFFSET
        {
            MBAP_TID_HIGH           = 0,
            MBAP_TID_LOW            = 1,
            MBAP_PID_HIGH           = 2,
            MBAP_PID_LOW            = 3,
            MBAP_LEN_HIGH          = 4,
            MBAP_LEN_LOW           = 5,
            UID                                   = 6,
            FUNC_CODE                   = 7,
            BYTE_COUNT                 = 8,
            DATA_START_READ       = 9,
            DATA_START_WRITE     = 10,
            START_ADDR_HIGH       = 8,
            START_ADDR_LOW        = 9,
            LENGTH_HIGH                = 10,
            LENGTH_LOW                 = 11
        };
        private MBAP mbap;
        private byte funcCode;
        private byte byteCount; // for read func
        private short startAddr;
        private short length;
        private short[] read_data;

        public ModbusTCP_Parser()
        {
            mbap = new MBAP();
            funcCode = (byte)FUNCTION_CODE.NONE;
            read_data = new short[MAX_DATA];
        }

        public bool modbus_Parse(byte[] data, Form1 form)
        {
            mbap.tid = (short)((data[(int)OFFSET.MBAP_TID_HIGH] << 8) + data[(int)OFFSET.MBAP_TID_LOW]);
            mbap.pid = (short)((data[(int)OFFSET.MBAP_PID_HIGH] << 8) + data[(int)OFFSET.MBAP_PID_LOW]);
            mbap.length = (short)((data[(int)OFFSET.MBAP_LEN_HIGH] << 8) + data[(int)OFFSET.MBAP_LEN_LOW]);
            mbap.uid = data[(int)OFFSET.UID];

            funcCode = data[(int)OFFSET.FUNC_CODE];

            string str;
            switch(funcCode)
            {
                case (byte)FUNCTION_CODE.READ_COILES:
                case (byte)FUNCTION_CODE.READ_DISCRETE_INPUTS:
                case (byte)FUNCTION_CODE.READ_MULTI_HREG:
                case (byte)FUNCTION_CODE.READ_INPUT_REG:
                    byteCount = data[(int)OFFSET.BYTE_COUNT];
                    for (int i = 0; i < byteCount; i += 2)
                    {
                        if (i == 0)
                        {
                            read_data[i] = (short)(data[(int)OFFSET.DATA_START_READ + i] << 8);
                            read_data[i] += data[(int)OFFSET.DATA_START_READ + i + 1];
                            continue;
                        }
                        read_data[i / 2] = (short)(data[(int)OFFSET.DATA_START_READ + i] << 8);
                        read_data[i / 2] += data[(int)OFFSET.DATA_START_READ + i + 1];
                    }

                    str = string.Format("0x{0,02:X2} 0x{1,2:X2} | " + "0x{2,2:X2} 0x{3,2:X2}\n" +
                        "0x{4,2:X2} 0x{5,2:X2} | " + "0x{6,2:X2} 0x{7,2:X2}\n" +
                        "0x{8,2:X2} 0x{9,2:X2} | " + "0x{10,2:X2} 0x{11,2:X2}\n", strs[0], mbap.tid, strs[1], mbap.pid, strs[2], mbap.length, strs[3], mbap.uid, strs[4], funcCode, strs[5], byteCount);
                    form.richText_Recv.AppendText(str);

                    if (byteCount == 1)
                    {
                        form.richText_Recv.AppendText(string.Format("Data{0} -----> 0x{1,4:X4}\n\n", 1, data[(int)OFFSET.DATA_START_READ]));
                    }
                    else
                    {
                        int cnt;
                        for (cnt = 0; cnt < byteCount / 2; cnt++)
                        {
                            if(cnt != 0 && cnt % 5 == 0) // 5개의 데이터마다 줄바꿈
                            {
                                form.richText_Recv.AppendText("\n");
                            }
                            if (byteCount / 2 == cnt + 1)       // 마지막이라면 
                                form.richText_Recv.AppendText(string.Format("Data{0} -----> 0x{1,4:X4}", cnt + 1, read_data[cnt]));
                            else
                                form.richText_Recv.AppendText(string.Format("Data{0} -----> 0x{1,4:X4} | ", cnt + 1, read_data[cnt]));
                        }

                        // read coil에서는 byte의 수가 홀수가 올 수 있기 때문에 마지막 1바이트를 처리하기 위한 루틴
                        if (byteCount % 2 == 1)
                        {
                            form.richText_Recv.AppendText(string.Format(" | Data{0} -----> 0x{1,4:X4}\n\n", cnt + 1, read_data[cnt]));
                        }
                        else
                        {
                            form.richText_Recv.AppendText("\n");
                        }

                        form.richText_Recv.AppendText("\n");
                    }
                    break;

                case (byte)FUNCTION_CODE.WRITE_SINGLE_HREG:
                case (byte)FUNCTION_CODE.WRITE_MULTI_HREGS:
                case (byte)FUNCTION_CODE.WRITE_SINGLE_COIL:
                case (byte)FUNCTION_CODE.WRITE_MULTIPLE_COILS:
                    startAddr = (short)((data[(int)OFFSET.START_ADDR_HIGH] << 8) +(data[(int)OFFSET.START_ADDR_LOW]));
                    length = (short)((data[(int)OFFSET.LENGTH_HIGH] << 8) + (data[(int)OFFSET.LENGTH_LOW]));

                    str = string.Format("0x{0,2:X2} 0x{1,2:X2} | " + "0x{2,2:X2} 0x{3,2:X2}\n" +
                        "0x{4,2:X2} 0x{5,2:X2} | " + "0x{6,2:X2} 0x{7,2:X2}\n" +
                        "0x{8,2:X2} 0x{9,2:X2} | " + "0x{10,2:X2} 0x{11,2:X2}\n" +
                        "0x{12,2:X2} 0x{13,2:X2} | " + "0x{14,2:X2} 0x{15,2:X2}\n", strs[0], mbap.tid, strs[1], mbap.pid, strs[2], mbap.length, strs[3], mbap.uid, strs[4], funcCode, strs[5], byteCount, strs[6], startAddr, strs[7], length);
                    form.richText_Recv.AppendText(str);
                    form.richText_Recv.AppendText("\n");
                    break;
            }

            return true;
        }
    }
}
