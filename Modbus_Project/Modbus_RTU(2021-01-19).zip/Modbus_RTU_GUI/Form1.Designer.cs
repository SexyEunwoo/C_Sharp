﻿
namespace Modbus_RTU_GUI
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.combo_Ports = new System.Windows.Forms.ComboBox();
            this.label_PortList = new System.Windows.Forms.Label();
            this.lab_Baud = new System.Windows.Forms.Label();
            this.combo_Baud = new System.Windows.Forms.ComboBox();
            this.lab_DataBit = new System.Windows.Forms.Label();
            this.combo_DataBit = new System.Windows.Forms.ComboBox();
            this.lab_ParityBit = new System.Windows.Forms.Label();
            this.combo_ParityBit = new System.Windows.Forms.ComboBox();
            this.lab_StopBit = new System.Windows.Forms.Label();
            this.combo_StopBit = new System.Windows.Forms.ComboBox();
            this.text_SlaveID = new System.Windows.Forms.TextBox();
            this.lab_SlaveID = new System.Windows.Forms.Label();
            this.lab_FuncCode = new System.Windows.Forms.Label();
            this.lab_StartAddr = new System.Windows.Forms.Label();
            this.lab_Length = new System.Windows.Forms.Label();
            this.text_StartAddr = new System.Windows.Forms.TextBox();
            this.text_FuncCode = new System.Windows.Forms.TextBox();
            this.text_Length = new System.Windows.Forms.TextBox();
            this.richText_RecvData = new System.Windows.Forms.RichTextBox();
            this.but_SerialOpen = new System.Windows.Forms.Button();
            this.but_Send = new System.Windows.Forms.Button();
            this.but_Close = new System.Windows.Forms.Button();
            this.but_AutoStart = new System.Windows.Forms.Button();
            this.but_AutoStop = new System.Windows.Forms.Button();
            this.text_Interval = new System.Windows.Forms.TextBox();
            this.lab_Interval = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // combo_Ports
            // 
            this.combo_Ports.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Ports.FormattingEnabled = true;
            this.combo_Ports.IntegralHeight = false;
            this.combo_Ports.Location = new System.Drawing.Point(73, 8);
            this.combo_Ports.Name = "combo_Ports";
            this.combo_Ports.Size = new System.Drawing.Size(121, 20);
            this.combo_Ports.TabIndex = 1;
            // 
            // label_PortList
            // 
            this.label_PortList.AutoSize = true;
            this.label_PortList.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_PortList.ForeColor = System.Drawing.Color.White;
            this.label_PortList.Location = new System.Drawing.Point(14, 13);
            this.label_PortList.Name = "label_PortList";
            this.label_PortList.Size = new System.Drawing.Size(39, 16);
            this.label_PortList.TabIndex = 2;
            this.label_PortList.Text = "Ports";
            // 
            // lab_Baud
            // 
            this.lab_Baud.AutoSize = true;
            this.lab_Baud.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Baud.ForeColor = System.Drawing.Color.White;
            this.lab_Baud.Location = new System.Drawing.Point(14, 53);
            this.lab_Baud.Name = "lab_Baud";
            this.lab_Baud.Size = new System.Drawing.Size(37, 16);
            this.lab_Baud.TabIndex = 4;
            this.lab_Baud.Text = "Baud";
            // 
            // combo_Baud
            // 
            this.combo_Baud.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_Baud.FormattingEnabled = true;
            this.combo_Baud.IntegralHeight = false;
            this.combo_Baud.Location = new System.Drawing.Point(73, 48);
            this.combo_Baud.Name = "combo_Baud";
            this.combo_Baud.Size = new System.Drawing.Size(121, 20);
            this.combo_Baud.TabIndex = 3;
            // 
            // lab_DataBit
            // 
            this.lab_DataBit.AutoSize = true;
            this.lab_DataBit.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_DataBit.ForeColor = System.Drawing.Color.White;
            this.lab_DataBit.Location = new System.Drawing.Point(14, 93);
            this.lab_DataBit.Name = "lab_DataBit";
            this.lab_DataBit.Size = new System.Drawing.Size(50, 16);
            this.lab_DataBit.TabIndex = 6;
            this.lab_DataBit.Text = "DataBit";
            // 
            // combo_DataBit
            // 
            this.combo_DataBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_DataBit.FormattingEnabled = true;
            this.combo_DataBit.IntegralHeight = false;
            this.combo_DataBit.Location = new System.Drawing.Point(73, 88);
            this.combo_DataBit.Name = "combo_DataBit";
            this.combo_DataBit.Size = new System.Drawing.Size(121, 20);
            this.combo_DataBit.TabIndex = 5;
            // 
            // lab_ParityBit
            // 
            this.lab_ParityBit.AutoSize = true;
            this.lab_ParityBit.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ParityBit.ForeColor = System.Drawing.Color.White;
            this.lab_ParityBit.Location = new System.Drawing.Point(14, 133);
            this.lab_ParityBit.Name = "lab_ParityBit";
            this.lab_ParityBit.Size = new System.Drawing.Size(60, 16);
            this.lab_ParityBit.TabIndex = 8;
            this.lab_ParityBit.Text = "Parity Bit";
            // 
            // combo_ParityBit
            // 
            this.combo_ParityBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_ParityBit.FormattingEnabled = true;
            this.combo_ParityBit.IntegralHeight = false;
            this.combo_ParityBit.Location = new System.Drawing.Point(73, 128);
            this.combo_ParityBit.Name = "combo_ParityBit";
            this.combo_ParityBit.Size = new System.Drawing.Size(121, 20);
            this.combo_ParityBit.TabIndex = 7;
            // 
            // lab_StopBit
            // 
            this.lab_StopBit.AutoSize = true;
            this.lab_StopBit.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_StopBit.ForeColor = System.Drawing.Color.White;
            this.lab_StopBit.Location = new System.Drawing.Point(14, 173);
            this.lab_StopBit.Name = "lab_StopBit";
            this.lab_StopBit.Size = new System.Drawing.Size(52, 16);
            this.lab_StopBit.TabIndex = 10;
            this.lab_StopBit.Text = "Stop Bit";
            // 
            // combo_StopBit
            // 
            this.combo_StopBit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_StopBit.FormattingEnabled = true;
            this.combo_StopBit.IntegralHeight = false;
            this.combo_StopBit.Location = new System.Drawing.Point(73, 168);
            this.combo_StopBit.Name = "combo_StopBit";
            this.combo_StopBit.Size = new System.Drawing.Size(121, 20);
            this.combo_StopBit.TabIndex = 9;
            // 
            // text_SlaveID
            // 
            this.text_SlaveID.Location = new System.Drawing.Point(296, 8);
            this.text_SlaveID.Name = "text_SlaveID";
            this.text_SlaveID.Size = new System.Drawing.Size(121, 21);
            this.text_SlaveID.TabIndex = 12;
            // 
            // lab_SlaveID
            // 
            this.lab_SlaveID.AutoSize = true;
            this.lab_SlaveID.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_SlaveID.ForeColor = System.Drawing.Color.White;
            this.lab_SlaveID.Location = new System.Drawing.Point(218, 13);
            this.lab_SlaveID.Name = "lab_SlaveID";
            this.lab_SlaveID.Size = new System.Drawing.Size(54, 16);
            this.lab_SlaveID.TabIndex = 15;
            this.lab_SlaveID.Text = "SlaveID";
            // 
            // lab_FuncCode
            // 
            this.lab_FuncCode.AutoSize = true;
            this.lab_FuncCode.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_FuncCode.ForeColor = System.Drawing.Color.White;
            this.lab_FuncCode.Location = new System.Drawing.Point(218, 53);
            this.lab_FuncCode.Name = "lab_FuncCode";
            this.lab_FuncCode.Size = new System.Drawing.Size(64, 16);
            this.lab_FuncCode.TabIndex = 16;
            this.lab_FuncCode.Text = "FuncCode";
            // 
            // lab_StartAddr
            // 
            this.lab_StartAddr.AutoSize = true;
            this.lab_StartAddr.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_StartAddr.ForeColor = System.Drawing.Color.White;
            this.lab_StartAddr.Location = new System.Drawing.Point(218, 93);
            this.lab_StartAddr.Name = "lab_StartAddr";
            this.lab_StartAddr.Size = new System.Drawing.Size(65, 16);
            this.lab_StartAddr.TabIndex = 17;
            this.lab_StartAddr.Text = "StartAddr";
            // 
            // lab_Length
            // 
            this.lab_Length.AutoSize = true;
            this.lab_Length.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Length.ForeColor = System.Drawing.Color.White;
            this.lab_Length.Location = new System.Drawing.Point(218, 133);
            this.lab_Length.Name = "lab_Length";
            this.lab_Length.Size = new System.Drawing.Size(47, 16);
            this.lab_Length.TabIndex = 18;
            this.lab_Length.Text = "Length";
            // 
            // text_StartAddr
            // 
            this.text_StartAddr.Location = new System.Drawing.Point(296, 88);
            this.text_StartAddr.Name = "text_StartAddr";
            this.text_StartAddr.Size = new System.Drawing.Size(121, 21);
            this.text_StartAddr.TabIndex = 20;
            // 
            // text_FuncCode
            // 
            this.text_FuncCode.Location = new System.Drawing.Point(296, 48);
            this.text_FuncCode.Name = "text_FuncCode";
            this.text_FuncCode.Size = new System.Drawing.Size(121, 21);
            this.text_FuncCode.TabIndex = 19;
            // 
            // text_Length
            // 
            this.text_Length.Location = new System.Drawing.Point(296, 128);
            this.text_Length.Name = "text_Length";
            this.text_Length.Size = new System.Drawing.Size(121, 21);
            this.text_Length.TabIndex = 21;
            // 
            // richText_RecvData
            // 
            this.richText_RecvData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richText_RecvData.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richText_RecvData.Location = new System.Drawing.Point(14, 207);
            this.richText_RecvData.Name = "richText_RecvData";
            this.richText_RecvData.ReadOnly = true;
            this.richText_RecvData.Size = new System.Drawing.Size(526, 141);
            this.richText_RecvData.TabIndex = 22;
            this.richText_RecvData.Text = "";
            // 
            // but_SerialOpen
            // 
            this.but_SerialOpen.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_SerialOpen.Location = new System.Drawing.Point(435, 6);
            this.but_SerialOpen.Name = "but_SerialOpen";
            this.but_SerialOpen.Size = new System.Drawing.Size(106, 22);
            this.but_SerialOpen.TabIndex = 23;
            this.but_SerialOpen.Text = "Serial Open";
            this.but_SerialOpen.UseVisualStyleBackColor = true;
            this.but_SerialOpen.Click += new System.EventHandler(this.but_SerialOpen_Click);
            // 
            // but_Send
            // 
            this.but_Send.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_Send.Location = new System.Drawing.Point(435, 88);
            this.but_Send.Name = "but_Send";
            this.but_Send.Size = new System.Drawing.Size(106, 54);
            this.but_Send.TabIndex = 24;
            this.but_Send.Text = "Send";
            this.but_Send.UseVisualStyleBackColor = true;
            this.but_Send.Click += new System.EventHandler(this.but_Send_Click);
            // 
            // but_Close
            // 
            this.but_Close.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_Close.Location = new System.Drawing.Point(435, 43);
            this.but_Close.Name = "but_Close";
            this.but_Close.Size = new System.Drawing.Size(106, 22);
            this.but_Close.TabIndex = 25;
            this.but_Close.Text = "Serial Close";
            this.but_Close.UseVisualStyleBackColor = true;
            this.but_Close.Click += new System.EventHandler(this.but_Close_Click);
            // 
            // but_AutoStart
            // 
            this.but_AutoStart.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_AutoStart.Location = new System.Drawing.Point(435, 161);
            this.but_AutoStart.Name = "but_AutoStart";
            this.but_AutoStart.Size = new System.Drawing.Size(53, 32);
            this.but_AutoStart.TabIndex = 26;
            this.but_AutoStart.Text = "Start";
            this.but_AutoStart.UseVisualStyleBackColor = true;
            this.but_AutoStart.Click += new System.EventHandler(this.but_AutoStart_Click);
            // 
            // but_AutoStop
            // 
            this.but_AutoStop.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.but_AutoStop.Location = new System.Drawing.Point(487, 161);
            this.but_AutoStop.Name = "but_AutoStop";
            this.but_AutoStop.Size = new System.Drawing.Size(53, 32);
            this.but_AutoStop.TabIndex = 27;
            this.but_AutoStop.Text = "Stop";
            this.but_AutoStop.UseVisualStyleBackColor = true;
            this.but_AutoStop.Click += new System.EventHandler(this.but_AutoStop_Click);
            // 
            // text_Interval
            // 
            this.text_Interval.Location = new System.Drawing.Point(296, 167);
            this.text_Interval.Name = "text_Interval";
            this.text_Interval.Size = new System.Drawing.Size(121, 21);
            this.text_Interval.TabIndex = 29;
            // 
            // lab_Interval
            // 
            this.lab_Interval.AutoSize = true;
            this.lab_Interval.Font = new System.Drawing.Font("Bahnschrift", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Interval.ForeColor = System.Drawing.Color.White;
            this.lab_Interval.Location = new System.Drawing.Point(218, 172);
            this.lab_Interval.Name = "lab_Interval";
            this.lab_Interval.Size = new System.Drawing.Size(80, 16);
            this.lab_Interval.TabIndex = 28;
            this.lab_Interval.Text = "Interval(ms)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(554, 355);
            this.Controls.Add(this.text_Interval);
            this.Controls.Add(this.lab_Interval);
            this.Controls.Add(this.but_AutoStop);
            this.Controls.Add(this.but_AutoStart);
            this.Controls.Add(this.but_Close);
            this.Controls.Add(this.but_Send);
            this.Controls.Add(this.but_SerialOpen);
            this.Controls.Add(this.richText_RecvData);
            this.Controls.Add(this.text_Length);
            this.Controls.Add(this.text_StartAddr);
            this.Controls.Add(this.text_FuncCode);
            this.Controls.Add(this.lab_Length);
            this.Controls.Add(this.lab_StartAddr);
            this.Controls.Add(this.lab_FuncCode);
            this.Controls.Add(this.lab_SlaveID);
            this.Controls.Add(this.text_SlaveID);
            this.Controls.Add(this.lab_StopBit);
            this.Controls.Add(this.combo_StopBit);
            this.Controls.Add(this.lab_ParityBit);
            this.Controls.Add(this.combo_ParityBit);
            this.Controls.Add(this.lab_DataBit);
            this.Controls.Add(this.combo_DataBit);
            this.Controls.Add(this.lab_Baud);
            this.Controls.Add(this.combo_Baud);
            this.Controls.Add(this.label_PortList);
            this.Controls.Add(this.combo_Ports);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox combo_Ports;
        private System.Windows.Forms.Label label_PortList;
        private System.Windows.Forms.Label lab_Baud;
        private System.Windows.Forms.ComboBox combo_Baud;
        private System.Windows.Forms.Label lab_DataBit;
        private System.Windows.Forms.ComboBox combo_DataBit;
        private System.Windows.Forms.Label lab_ParityBit;
        private System.Windows.Forms.ComboBox combo_ParityBit;
        private System.Windows.Forms.Label lab_StopBit;
        private System.Windows.Forms.ComboBox combo_StopBit;
        private System.Windows.Forms.TextBox text_SlaveID;
        private System.Windows.Forms.Label lab_SlaveID;
        private System.Windows.Forms.Label lab_FuncCode;
        private System.Windows.Forms.Label lab_StartAddr;
        private System.Windows.Forms.Label lab_Length;
        private System.Windows.Forms.TextBox text_StartAddr;
        private System.Windows.Forms.TextBox text_FuncCode;
        private System.Windows.Forms.TextBox text_Length;
        private System.Windows.Forms.RichTextBox richText_RecvData;
        private System.Windows.Forms.Button but_SerialOpen;
        private System.Windows.Forms.Button but_Send;
        private System.Windows.Forms.Button but_Close;
        private System.Windows.Forms.Button but_AutoStart;
        private System.Windows.Forms.Button but_AutoStop;
        private System.Windows.Forms.TextBox text_Interval;
        private System.Windows.Forms.Label lab_Interval;
    }
}

